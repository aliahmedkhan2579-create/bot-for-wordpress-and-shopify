# Autonomous WordPress & Shopify ZIP Generator AI Agent

A fully autonomous AI agent and web application that accepts user requirements and automatically synthesizes complete, functional, standards-compliant, validated, and installable ZIP archives for:
1. **Custom WordPress Themes** (Classic, Block / FSE, and WooCommerce compatible)
2. **Custom WordPress Plugins** (Object-oriented architecture, CPTs, AJAX handlers with nonces, REST API routes, settings panels, and uninstall routines)
3. **Custom Shopify Online Store 2.0 Themes** (Liquid templates, JSON templates, dynamic sections with schema presets, cart drawer, `settings_schema.json`, and locales)

---

## 🌟 Key Features

- **10-Step Autonomous Pipeline**:
  1. Requirements Analysis & Feature Taxonomy Extraction
  2. Internal Architectural Development Plan
  3. Source Code, Asset & Image Generation
  4. Standards-Compliant Directory Tree Organization
  5. UI Theming, Security Nonces & Schema Implementation
  6. Multi-Stage Code Validation (JS AST syntax, CSS balancing, JSON & Liquid schema parsing, theme/plugin headers)
  7. Automated Self-Healing Error Fix Loop
  8. Post-Fix Verification Audit
  9. Installable Clean ZIP Packaging & Checksum Verification
  10. Direct Download Delivery & Disk Path Exposure
- **Zero-Config Built-in Synthesis Engine**: Works 100% offline out-of-the-box with zero API keys and zero cost.
- **Configurable AI Layer**: Optionally switch to Google Gemini (e.g., `gemini-2.5-flash`), OpenAI (`gpt-4o`), Anthropic Claude (`claude-3-5-sonnet`), or local LLMs (Ollama / LM Studio).
- **Existing ZIP Modification**: Upload an existing theme or plugin ZIP to modify or add features without overwriting original files.
- **Project Isolation**: Every project runs in an isolated workspace under `data/workspaces/<projectId>`.
- **Live Terminal & Streaming Progress**: Real-time progress updates via Server-Sent Events (SSE).

---

## 🚀 Quick Start Guide

### 1. Start the Server
From this project directory:
```bash
npm start
```
The server will boot at:
```
http://localhost:3456
```

### 2. Run Automated Verification Tests
```bash
npm test
```
This executes the automated end-to-end verification suite testing all 3 CMS types.

---

## 📦 How to Install Generated Archives

### Installing a WordPress Theme
1. Log in to your WordPress Admin dashboard (`/wp-admin`).
2. Go to **Appearance > Themes**.
3. Click **Add New Theme** at the top.
4. Click **Upload Theme**.
5. Choose your generated `<theme-slug>.zip` file and click **Install Now**.
6. Click **Activate**.

### Installing a WordPress Plugin
1. Log in to your WordPress Admin dashboard (`/wp-admin`).
2. Go to **Plugins > Add New Plugin**.
3. Click **Upload Plugin** at the top.
4. Choose your generated `<plugin-slug>.zip` file and click **Install Now**.
5. Click **Activate Plugin**.
6. Access your plugin's configuration page directly in the admin navigation menu.

### Installing a Shopify Theme (Online Store 2.0)
1. Log in to your Shopify Admin (`admin.shopify.com`).
2. In the left navigation, click **Online Store > Themes**.
3. In the Theme library section, click **Add theme > Upload zip file**.
4. Choose your generated `<shopify-theme-slug>.zip` file and click **Upload file**.
5. Once uploaded, click **Customize** to edit sections or **Publish** to make it your live store.

---

## 🛠️ Project Structure
```
autonomous-wp-shopify-agent/
├── package.json               # Node.js dependencies (express, multer, adm-zip)
├── server.js                  # Express API server, SSE streaming, file uploads
├── public/                    # Web User Interface
│   ├── index.html             # Clean responsive UI
│   ├── app.js                 # Frontend application & SSE client
│   └── style.css              # Custom styling & dark developer theme
├── src/
│   ├── config.js              # Environment & directory configurations
│   ├── orchestrator.js        # 10-step autonomous workflow controller
│   ├── ai/
│   │   └── ai-service.js      # Unified AI provider (Built-in, Gemini, OpenAI, Claude, Local)
│   ├── generators/
│   │   ├── wordpress-theme.js # Complete WordPress theme generator
│   │   ├── wordpress-plugin.js# Complete WordPress plugin generator
│   │   ├── shopify-theme.js   # Complete Shopify OS 2.0 generator
│   │   └── png-generator.js   # Valid PNG theme screenshot creator
│   ├── validator/
│   │   └── code-validator.js  # Multi-stage validator & auto-fix engine
│   ├── packager/
│   │   └── zip-packager.js    # Clean ZIP archiver & integrity auditor
│   └── workspace/
│       └── project-manager.js # Isolated workspaces & persistent database
├── data/
│   ├── workspaces/            # Isolated project workspaces
│   ├── uploads/               # Preserved reference & source uploads
│   ├── dist/                  # Generated & verified ZIP archives
│   └── projects.json          # Persistent project store
└── tests/
    └── test-samples.js        # End-to-end verification test suite
```
