const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const AdmZip = require('adm-zip');

class ZipPackager {
  constructor(distDir) {
    this.distDir = distDir;
    if (!fs.existsSync(this.distDir)) {
      fs.mkdirSync(this.distDir, { recursive: true });
    }
  }

  /**
   * Packages project files into an installable ZIP archive
   * @param {string} projectId Unique project ID
   * @param {string} projectType 'wordpress_theme' | 'wordpress_plugin' | 'shopify_theme'
   * @param {string} slug Project slug
   * @param {Object} files Object mapping relative paths to content (string | Buffer)
   * @returns {Object} Packaging verification details
   */
  async package(projectId, projectType, slug, files) {
    const projectDistDir = path.join(this.distDir, projectId);
    if (!fs.existsSync(projectDistDir)) {
      fs.mkdirSync(projectDistDir, { recursive: true });
    }

    const zipFileName = `${slug}.zip`;
    const zipFilePath = path.join(projectDistDir, zipFileName);

    const zip = new AdmZip();

    // Determine root prefix based on platform requirements
    let rootPrefix = '';
    if (projectType === 'wordpress_theme' || projectType === 'wordpress_plugin') {
      // WordPress themes and plugins MUST have the root folder in the ZIP
      rootPrefix = `${slug}/`;
    } else {
      // Shopify Online Store 2.0 themes require files at the zip root
      rootPrefix = '';
    }

    // Filter out unsafe / temporary items
    const ignoredNames = ['.git', '.DS_Store', 'Thumbs.db', '.env', 'node_modules', '.tmp'];

    for (const [relPath, content] of Object.entries(files)) {
      const isIgnored = ignoredNames.some(ign => relPath.includes(ign));
      if (isIgnored) continue;

      const zipEntryPath = rootPrefix ? `${rootPrefix}${relPath}`.replace(/\\/g, '/') : relPath.replace(/\\/g, '/');
      const entryDir = path.dirname(zipEntryPath);

      const buffer = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8');
      zip.addFile(zipEntryPath, buffer);
    }

    // Write ZIP to disk
    zip.writeZip(zipFilePath);

    // Strict Verification Step
    if (!fs.existsSync(zipFilePath)) {
      throw new Error(`ZIP file was not created at ${zipFilePath}`);
    }

    const stats = fs.statSync(zipFilePath);
    if (stats.size === 0) {
      throw new Error('Created ZIP archive is empty (0 bytes).');
    }

    // Re-open and verify ZIP entries
    const verifyZip = new AdmZip(zipFilePath);
    const entries = verifyZip.getEntries();
    if (!entries || entries.length === 0) {
      throw new Error('Verification failed: ZIP contains 0 entries.');
    }

    const entryNames = entries.map(e => e.entryName);

    // Compute SHA-256 Checksum
    const fileBuffer = fs.readFileSync(zipFilePath);
    const hash = crypto.createHash('sha256').update(fileBuffer).digest('hex');

    return {
      success: true,
      zipPath: zipFilePath,
      fileName: zipFileName,
      fileSize: stats.size,
      fileSizeFormatted: (stats.size / 1024).toFixed(1) + ' KB',
      fileCount: entries.length,
      entries: entryNames,
      sha256: hash,
      verified: true,
      verifiedAt: new Date().toISOString()
    };
  }
}

module.exports = { ZipPackager };
