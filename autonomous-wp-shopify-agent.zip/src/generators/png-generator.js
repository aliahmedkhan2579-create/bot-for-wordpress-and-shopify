const zlib = require('node:zlib');

/**
 * Generates a valid uncompressed / deflate-compressed PNG buffer
 * with a stylish branded theme banner.
 * Width: 800, Height: 600 (standard WordPress theme screenshot ratio 4:3)
 */
function createScreenshotPng(themeName = 'Custom Theme', primaryColor = [45, 85, 255]) {
  const width = 400;
  const height = 300;
  
  // RGBA buffer for raw uncompressed image data
  // Each row starts with a filter byte (0 = None) followed by width * 4 bytes
  const rowStride = 1 + width * 4;
  const rawData = Buffer.alloc(rowStride * height);

  const [pr, pg, pb] = primaryColor;
  const bgR = 248, bgG = 250, bgB = 252; // slate-50

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowStride;
    rawData[rowOffset] = 0; // Filter: None

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;

      // Header card top area
      if (y < 60) {
        rawData[pixelOffset + 0] = pr;
        rawData[pixelOffset + 1] = pg;
        rawData[pixelOffset + 2] = pb;
        rawData[pixelOffset + 3] = 255;
      } else if (y > 80 && y < 220 && x > 30 && x < width - 30) {
        // Inner preview mockup card
        if (y === 81 || y === 219 || x === 31 || x === width - 31) {
          // Border
          rawData[pixelOffset + 0] = 203;
          rawData[pixelOffset + 1] = 213;
          rawData[pixelOffset + 2] = 225;
          rawData[pixelOffset + 3] = 255;
        } else if (y < 110) {
          // Hero header inside mockup
          rawData[pixelOffset + 0] = Math.min(255, pr + 40);
          rawData[pixelOffset + 1] = Math.min(255, pg + 40);
          rawData[pixelOffset + 2] = Math.min(255, pb + 40);
          rawData[pixelOffset + 3] = 255;
        } else {
          // Card body
          rawData[pixelOffset + 0] = 255;
          rawData[pixelOffset + 1] = 255;
          rawData[pixelOffset + 2] = 255;
          rawData[pixelOffset + 3] = 255;
        }
      } else {
        // Background
        rawData[pixelOffset + 0] = bgR;
        rawData[pixelOffset + 1] = bgG;
        rawData[pixelOffset + 2] = bgB;
        rawData[pixelOffset + 3] = 255;
      }
    }
  }

  // Compress IDAT chunk
  const compressedData = zlib.deflateSync(rawData);

  // Construct PNG chunks: Signature, IHDR, IDAT, IEND
  const signature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // Bit depth: 8
  ihdrData[9] = 6; // Color type: RGBA
  ihdrData[10] = 0; // Compression: Deflate
  ihdrData[11] = 0; // Filter: Standard
  ihdrData[12] = 0; // Interlace: None
  const ihdrChunk = createPngChunk('IHDR', ihdrData);

  // IDAT
  const idatChunk = createPngChunk('IDAT', compressedData);

  // IEND
  const iendChunk = createPngChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createPngChunk(type, data) {
  const length = data.length;
  const chunk = Buffer.alloc(8 + length + 4);
  chunk.writeUInt32BE(length, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);

  const crc = crc32(Buffer.concat([Buffer.from(type, 'ascii'), data]));
  chunk.writeUInt32BE(crc >>> 0, 8 + length);
  return chunk;
}

// CRC32 table for PNG chunk checksum
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return c ^ 0xffffffff;
}

module.exports = { createScreenshotPng };
