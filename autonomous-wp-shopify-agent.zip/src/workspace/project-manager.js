const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const AdmZip = require('adm-zip');

class ProjectManager extends EventEmitter {
  constructor(config) {
    super();
    this.workspacesDir = config.WORKSPACES_DIR;
    this.uploadsDir = config.UPLOADS_DIR;
    this.distDir = config.DIST_DIR;
    this.dbFile = config.DB_FILE;

    // Ensure base directories exist
    [this.workspacesDir, this.uploadsDir, this.distDir, path.dirname(this.dbFile)].forEach(dir => {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });

    this.projects = this.loadDatabase();
  }

  loadDatabase() {
    try {
      if (fs.existsSync(this.dbFile)) {
        const raw = fs.readFileSync(this.dbFile, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn('[ProjectManager] Failed to read database file, creating fresh store.', err.message);
    }
    return [];
  }

  saveDatabase() {
    try {
      fs.writeFileSync(this.dbFile, JSON.stringify(this.projects, null, 2), 'utf8');
    } catch (err) {
      console.error('[ProjectManager] Error saving projects database:', err.message);
    }
  }

  getAllProjects() {
    return [...this.projects].reverse();
  }

  getProject(id) {
    return this.projects.find(p => p.id === id) || null;
  }

  /**
   * Creates an isolated workspace for a new project
   */
  createProject(data) {
    const id = crypto.randomUUID();
    const workspacePath = path.join(this.workspacesDir, id);
    const projectUploadsDir = path.join(this.uploadsDir, id);

    fs.mkdirSync(workspacePath, { recursive: true });
    fs.mkdirSync(projectUploadsDir, { recursive: true });

    const newProject = {
      id,
      name: data.name || 'Untitled Project',
      slug: data.slug || 'custom-project',
      type: data.type || 'wordpress_theme',
      prompt: data.prompt || '',
      referenceUrl: data.referenceUrl || '',
      status: 'pending',
      step: 0,
      stepName: 'Initialized',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      workspacePath,
      uploadsPath: projectUploadsDir,
      plan: null,
      validationReport: null,
      zipInfo: null,
      uploadedFiles: [],
      isModification: false
    };

    this.projects.push(newProject);
    this.saveDatabase();
    return newProject;
  }

  updateProject(id, updates) {
    const project = this.getProject(id);
    if (!project) return null;

    Object.assign(project, updates, { updatedAt: new Date().toISOString() });
    this.saveDatabase();
    return project;
  }

  /**
   * Save an uploaded file in project uploads directory without overwriting
   */
  saveUploadedFile(projectId, fileBuffer, originalName) {
    const project = this.getProject(projectId);
    if (!project) throw new Error(`Project ${projectId} not found.`);

    const safeName = path.basename(originalName).replace(/[^a-zA-Z0-9._-]/g, '_');
    let targetPath = path.join(project.uploadsPath, safeName);

    // If file with same name exists, preserve by prefixing timestamp
    if (fs.existsSync(targetPath)) {
      const ext = path.extname(safeName);
      const base = path.basename(safeName, ext);
      targetPath = path.join(project.uploadsPath, `${base}_${Date.now()}${ext}`);
    }

    fs.writeFileSync(targetPath, fileBuffer);

    project.uploadedFiles.push({
      originalName,
      savedPath: targetPath,
      size: fileBuffer.length,
      uploadedAt: new Date().toISOString()
    });

    this.saveDatabase();
    return targetPath;
  }

  /**
   * If user uploads an existing ZIP to modify, extract into workspace
   */
  extractExistingZip(projectId, zipFilePath) {
    const project = this.getProject(projectId);
    if (!project) throw new Error(`Project ${projectId} not found.`);

    const zip = new AdmZip(zipFilePath);
    zip.extractAllTo(project.workspacePath, true);

    project.isModification = true;
    this.saveDatabase();

    // Read all extracted files into memory map
    return this.readWorkspaceFiles(project.workspacePath);
  }

  readWorkspaceFiles(dir, baseDir = dir) {
    const files = {};
    const items = fs.readdirSync(dir, { withFileTypes: true });

    for (const item of items) {
      const fullPath = path.join(dir, item.name);
      if (item.isDirectory()) {
        Object.assign(files, this.readWorkspaceFiles(fullPath, baseDir));
      } else {
        const rel = path.relative(baseDir, fullPath).replace(/\\/g, '/');
        // If image or binary, read buffer, otherwise string
        if (rel.endsWith('.png') || rel.endsWith('.jpg') || rel.endsWith('.ico')) {
          files[rel] = fs.readFileSync(fullPath);
        } else {
          files[rel] = fs.readFileSync(fullPath, 'utf8');
        }
      }
    }

    return files;
  }

  /**
   * Writes generated files into the isolated project workspace on disk
   */
  writeFilesToWorkspace(projectId, files) {
    const project = this.getProject(projectId);
    if (!project) throw new Error(`Project ${projectId} not found.`);

    for (const [relPath, content] of Object.entries(files)) {
      const fullPath = path.join(project.workspacePath, relPath);
      const dir = path.dirname(fullPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

      if (Buffer.isBuffer(content)) {
        fs.writeFileSync(fullPath, content);
      } else {
        fs.writeFileSync(fullPath, content, 'utf8');
      }
    }
  }

  emitStep(projectId, stepNum, stepName, details = {}) {
    const payload = {
      projectId,
      step: stepNum,
      stepName,
      timestamp: new Date().toISOString(),
      ...details
    };
    this.updateProject(projectId, { step: stepNum, stepName });
    this.emit('progress', payload);
  }
}

module.exports = { ProjectManager };
