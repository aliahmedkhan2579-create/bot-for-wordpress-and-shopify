const path = require('node:path');

const ROOT_DIR = path.resolve(__dirname, '..');
const WORKSPACES_DIR = path.join(ROOT_DIR, 'data', 'workspaces');
const UPLOADS_DIR = path.join(ROOT_DIR, 'data', 'uploads');
const DIST_DIR = path.join(ROOT_DIR, 'data', 'dist');
const DB_FILE = path.join(ROOT_DIR, 'data', 'projects.json');

module.exports = {
  PORT: process.env.PORT || 3456,
  ROOT_DIR,
  WORKSPACES_DIR,
  UPLOADS_DIR,
  DIST_DIR,
  DB_FILE,
  // Default AI settings
  DEFAULT_AI_CONFIG: {
    provider: 'builtin', // 'builtin' | 'gemini' | 'openai' | 'anthropic' | 'custom'
    apiKey: '',
    model: 'built-in-autonomous-engine',
    endpoint: ''
  }
};
