/**
 * Autonomous AI Provider Layer
 * Supports:
 * - Built-in Autonomous Blueprint & Synthesis Engine (100% offline, zero-config, free)
 * - Google Gemini API (gemini-2.5-flash, gemini-2.0-flash, gemini-1.5-pro)
 * - OpenAI API (gpt-4o, gpt-4o-mini)
 * - Anthropic Claude API (claude-3-5-sonnet)
 * - Custom / Local OpenAI-compatible provider (Ollama, LM Studio, LocalAI)
 */

class AIService {
  constructor(config = {}) {
    this.provider = config.provider || 'builtin';
    this.apiKey = config.apiKey || process.env.AI_API_KEY || '';
    this.model = config.model || this.getDefaultModel(this.provider);
    this.endpoint = config.endpoint || '';
  }

  getDefaultModel(provider) {
    switch (provider) {
      case 'gemini': return 'gemini-2.5-flash';
      case 'openai': return 'gpt-4o';
      case 'anthropic': return 'claude-3-5-sonnet-20241022';
      case 'custom': return 'llama3';
      default: return 'built-in-autonomous-engine';
    }
  }

  /**
   * Generates a comprehensive architectural plan for the project
   */
  async generatePlan(projectType, prompt, metadata = {}) {
    // If external AI provider configured and key exists, try LLM enrichment
    if (this.provider !== 'builtin' && this.apiKey) {
      try {
        const llmPlan = await this.callLLMForPlan(projectType, prompt, metadata);
        if (llmPlan) return llmPlan;
      } catch (err) {
        console.warn(`[AIService] External LLM failed (${err.message}), falling back to Autonomous Blueprint Engine.`);
      }
    }

    // Default Autonomous Blueprint Plan Engine
    return this.generateAutonomousBlueprintPlan(projectType, prompt, metadata);
  }

  generateAutonomousBlueprintPlan(projectType, prompt, metadata) {
    const slug = metadata.slug || this.slugify(metadata.name || prompt.slice(0, 30));
    const title = metadata.name || this.titleize(slug);
    const hasWooCommerce = /woo|shop|store|cart|checkout|ecommerce|e-commerce/i.test(prompt);
    const hasForms = /form|lead|contact|inquiry|booking|newsletter/i.test(prompt);
    const hasCPT = /post type|cpt|portfolio|property|event|testimonial|recipe|listing/i.test(prompt);
    const hasRestApi = /rest|api|endpoint|webhook|sync/i.test(prompt);
    const isBlockTheme = /block|fse|full site editing/i.test(prompt);

    if (projectType === 'wordpress_theme') {
      const arch = isBlockTheme ? 'Block Theme (FSE / Full Site Editing)' : (hasWooCommerce ? 'Hybrid Classic + WooCommerce Theme' : 'Modern Classic WordPress Theme');
      const files = [
        { path: 'style.css', purpose: 'WordPress Theme Header & Primary Styles' },
        { path: 'functions.php', purpose: 'Theme Setup, Hook Registrations, Asset Enqueuing & Custom Post Types' },
        { path: 'header.php', purpose: 'Semantic HTML5 Header, Navigation Bar & Custom Logo Support' },
        { path: 'footer.php', purpose: 'Footer Widget Areas, Copyright & wp_footer()' },
        { path: 'index.php', purpose: 'Main Fallback Template & Dynamic Blog Grid' },
        { path: 'single.php', purpose: 'Single Article Layout with Author Meta, Post Nav & Comments' },
        { path: 'page.php', purpose: 'Full-Width & Standard Page Content Template' },
        { path: 'archive.php', purpose: 'Category, Tag & Date Archive Listing with Pagination' },
        { path: 'search.php', purpose: 'Dynamic Search Results Template with Result Counter' },
        { path: '404.php', purpose: 'Custom Error Page with Search Box and Recommended Links' },
        { path: 'comments.php', purpose: 'Accessible Discussion & Comment Form Template' },
        { path: 'template-parts/content.php', purpose: 'Reusable Article Excerpt Card' },
        { path: 'template-parts/content-single.php', purpose: 'Article Body & Post Metadata Component' },
        { path: 'template-parts/content-none.php', purpose: 'Empty State Notification Component' },
        { path: 'assets/css/main.css', purpose: 'Responsive Mobile-First CSS Variables & Utility Styles' },
        { path: 'assets/js/main.js', purpose: 'Interactive Navigation Toggle, Accessible Dropdowns & Smooth Scroll' },
        { path: 'screenshot.png', purpose: 'Valid 800x600 Theme Preview Image for WordPress Admin' },
        { path: 'readme.txt', purpose: 'WordPress Standard Theme Documentation & Installation Guide' }
      ];

      if (hasWooCommerce) {
        files.push({ path: 'woocommerce.php', purpose: 'Dedicated WooCommerce Shop & Product Archive Wrapper' });
      }

      return {
        projectName: title,
        projectSlug: slug,
        projectType: 'wordpress_theme',
        architecture: arch,
        hasWooCommerce,
        description: prompt,
        milestones: [
          'Requirement & Taxonomy Extraction',
          'Theme Header and Assets Architecture',
          'Template Structure Generation (Single, Archive, Pages)',
          'Navigation, Customizer & Widget Registration',
          hasWooCommerce ? 'WooCommerce Compatibility Hooks & Styles' : 'Responsive Grid Layout',
          'Static Asset Bundling & Responsive CSS',
          'Theme Validation & Packaging'
        ],
        manifest: files
      };
    } else if (projectType === 'wordpress_plugin') {
      const files = [
        { path: `${slug}.php`, purpose: 'Main Plugin Bootstrap, Header, Security Guard & Life-cycle Hooks' },
        { path: 'uninstall.php', purpose: 'Database Cleanup & Options Sanitation on Plugin Deletion' },
        { path: `includes/class-${slug}-loader.php`, purpose: 'Central Action & Filter Hook Coordinator' },
        { path: `includes/class-${slug}-activator.php`, purpose: 'Activation Routine: Schema Migration & Default Options' },
        { path: `includes/class-${slug}-deactivator.php`, purpose: 'Deactivation Cleanup & Transient Flusher' },
        { path: `admin/class-${slug}-admin.php`, purpose: 'Admin Menus, Settings API, Nonce Verification & Scripts' },
        { path: `admin/partials/${slug}-admin-display.php`, purpose: 'Admin Dashboard Settings View' },
        { path: `admin/css/${slug}-admin.css`, purpose: 'Admin Dashboard Styles' },
        { path: `admin/js/${slug}-admin.js`, purpose: 'Admin Interactivity & Settings Validation' },
        { path: `public/class-${slug}-public.php`, purpose: 'Frontend Shortcodes, AJAX Handlers & REST API' },
        { path: `public/partials/${slug}-public-display.php`, purpose: 'Frontend Interactive Component View' },
        { path: `public/css/${slug}-public.css`, purpose: 'Frontend Component Styling' },
        { path: `public/js/${slug}-public.js`, purpose: 'Frontend Asynchronous AJAX Form Submission & UI Feedback' },
        { path: 'readme.txt', purpose: 'Standard WordPress Plugin Repository Readme & Docs' }
      ];

      return {
        projectName: title,
        projectSlug: slug,
        projectType: 'wordpress_plugin',
        architecture: 'Modular Object-Oriented WordPress Plugin Architecture',
        hasForms,
        hasCPT,
        hasRestApi,
        description: prompt,
        milestones: [
          'Plugin Header & Security Definition',
          'Activation & Deactivation Hook Subsystem',
          'Admin Settings API & Option Panels',
          'Frontend Shortcode & AJAX Handlers',
          'Nonce Verification & Sanitization Pipeline',
          'Public & Admin Asset Bundling',
          'Plugin Validation & Packaging'
        ],
        manifest: files
      };
    } else {
      // Shopify Online Store 2.0 Theme
      const files = [
        { path: 'layout/theme.liquid', purpose: 'Core OS 2.0 Layout with content_for_header, content_for_layout' },
        { path: 'layout/password.liquid', purpose: 'Password Page Layout for Pre-launch Store Access' },
        { path: 'templates/index.json', purpose: 'Homepage JSON Template Defining Dynamic Modular Sections' },
        { path: 'templates/product.json', purpose: 'Product Details JSON Template with Recommendation Blocks' },
        { path: 'templates/collection.json', purpose: 'Collection Grid JSON Template with Facet Filters' },
        { path: 'templates/cart.json', purpose: 'Shopping Cart Page JSON Template' },
        { path: 'templates/page.json', purpose: 'Standard Page JSON Template' },
        { path: 'templates/blog.json', purpose: 'Store Journal / Blog Listing JSON Template' },
        { path: 'templates/article.json', purpose: 'Single Blog Post JSON Template' },
        { path: 'templates/404.json', purpose: 'Not Found Page JSON Template' },
        { path: 'templates/search.json', purpose: 'Live Search Results JSON Template' },
        { path: 'sections/header.liquid', purpose: 'Configurable Navigation Header Section with Schema Settings' },
        { path: 'sections/footer.liquid', purpose: 'Configurable Multi-Column Footer with Schema Presets' },
        { path: 'sections/announcement-bar.liquid', purpose: 'Top Notification / Promo Banner Section' },
        { path: 'sections/hero-banner.liquid', purpose: 'Hero Image / CTA Section with Customizer Schema' },
        { path: 'sections/featured-collection.liquid', purpose: 'Dynamic Featured Products Carousel / Grid Section' },
        { path: 'sections/main-product.liquid', purpose: 'Product Form, Variant Selector & Add-to-Cart Section' },
        { path: 'sections/main-collection.liquid', purpose: 'Collection Products Grid with Filter Sidebar' },
        { path: 'sections/main-cart.liquid', purpose: 'Line Items Table & Cart Drawer Controller' },
        { path: 'sections/main-page.liquid', purpose: 'Static Page Container Section' },
        { path: 'snippets/product-card.liquid', purpose: 'Reusable Product Card Snippet with Quick Add Button' },
        { path: 'snippets/price.liquid', purpose: 'Currency Formatter & Discount Badge Snippet' },
        { path: 'snippets/icon.liquid', purpose: 'Scalable SVG Icons Snippet' },
        { path: 'snippets/cart-drawer.liquid', purpose: 'Interactive Slide-Out Mini-Cart Drawer Snippet' },
        { path: 'config/settings_schema.json', purpose: 'Shopify Customizer Settings Schema (Colors, Typography)' },
        { path: 'config/settings_data.json', purpose: 'Default Preset Settings for the Customizer' },
        { path: 'locales/en.default.json', purpose: 'Shopify OS 2.0 English Translation Strings' },
        { path: 'assets/theme.css', purpose: 'Theme CSS Styling with Modern CSS Custom Properties' },
        { path: 'assets/theme.js', purpose: 'AJAX Cart API Controller, Variant Changer & Mobile Menu JS' },
        { path: 'SHOPIFY_APP_REQUIREMENTS.md', purpose: 'Integration Guide for Features Requiring Apps / External APIs' }
      ];

      return {
        projectName: title,
        projectSlug: slug,
        projectType: 'shopify_theme',
        architecture: 'Shopify Online Store 2.0 (JSON Templates & Section Architecture)',
        description: prompt,
        milestones: [
          'Shopify OS 2.0 Directory Specification',
          'Layout & Global Liquid Wrapper Synthesis',
          'JSON Templates (Index, Product, Collection, Cart)',
          'Modular Sections with Customizer Schema Blocks',
          'Interactive Cart Drawer & Snippet Architecture',
          'Theme Settings Schema & Translation Locales',
          'Liquid Syntax Verification & Theme Zip Packaging'
        ],
        manifest: files
      };
    }
  }

  async callLLMForPlan(projectType, prompt, metadata) {
    const systemPrompt = `You are an expert full-stack developer and CMS architect specializing in WordPress and Shopify.
Analyze the user's requirements for a ${projectType} and return a JSON object with:
{
  "projectName": "string",
  "projectSlug": "string (lowercase-hyphenated)",
  "architecture": "string",
  "summary": "string",
  "milestones": ["string"],
  "specialFeatures": ["string"],
  "notes": "string"
}`;

    if (this.provider === 'gemini') {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent?key=${this.apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${systemPrompt}\n\nProject Requirements: ${prompt}` }] }],
          generationConfig: { responseMimeType: 'application/json' }
        })
      });
      if (!res.ok) throw new Error(`Gemini API returned ${res.status}: ${await res.text()}`);
      const data = await res.json();
      const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      const parsed = JSON.parse(rawText);
      const blueprint = this.generateAutonomousBlueprintPlan(projectType, prompt, {
        ...metadata,
        name: parsed.projectName,
        slug: parsed.projectSlug
      });
      return { ...blueprint, ...parsed };
    }

    if (this.provider === 'openai' || this.provider === 'custom') {
      const endpoint = this.endpoint || 'https://api.openai.com/v1/chat/completions';
      const headers = { 'Content-Type': 'application/json' };
      if (this.apiKey) headers['Authorization'] = `Bearer ${this.apiKey}`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: this.model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `Project Requirements: ${prompt}` }
          ],
          response_format: { type: 'json_object' }
        })
      });
      if (!res.ok) throw new Error(`AI API returned ${res.status}: ${await res.text()}`);
      const data = await res.json();
      const raw = data.choices?.[0]?.message?.content;
      const parsed = JSON.parse(raw);
      const blueprint = this.generateAutonomousBlueprintPlan(projectType, prompt, {
        ...metadata,
        name: parsed.projectName,
        slug: parsed.projectSlug
      });
      return { ...blueprint, ...parsed };
    }

    if (this.provider === 'anthropic') {
      const url = 'https://api.anthropic.com/v1/messages';
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: this.model,
          max_tokens: 1500,
          system: systemPrompt,
          messages: [{ role: 'user', content: `Project Requirements: ${prompt}. Output valid JSON only.` }]
        })
      });
      if (!res.ok) throw new Error(`Anthropic API returned ${res.status}: ${await res.text()}`);
      const data = await res.json();
      const raw = data.content?.[0]?.text;
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        const blueprint = this.generateAutonomousBlueprintPlan(projectType, prompt, {
          ...metadata,
          name: parsed.projectName,
          slug: parsed.projectSlug
        });
        return { ...blueprint, ...parsed };
      }
    }

    return null;
  }

  slugify(text) {
    return String(text || 'custom-project')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '') || 'custom-project';
  }

  titleize(slug) {
    return String(slug || 'Custom Project')
      .split('-')
      .map(w => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }
}

module.exports = { AIService };
