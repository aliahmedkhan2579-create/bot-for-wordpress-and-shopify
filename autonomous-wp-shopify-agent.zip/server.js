const express = require('express');
const path = require('node:path');
const fs = require('node:fs');
const multer = require('multer');

const config = require('./src/config');
const { ProjectManager } = require('./src/workspace/project-manager');
const { AgentOrchestrator } = require('./src/orchestrator');
const { AIService } = require('./src/ai/ai-service');

const app = express();
const pm = new ProjectManager(config);
const orchestrator = new AgentOrchestrator(pm, config);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Configure Multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB max per file
});

// SSE connection pool by project ID
const sseClients = new Map();

pm.on('progress', (data) => {
  const { projectId } = data;
  const clients = sseClients.get(projectId);
  if (clients && clients.length > 0) {
    const payload = `data: ${JSON.stringify(data)}\n\n`;
    clients.forEach(res => {
      try { res.write(payload); } catch {}
    });
  }
});

// Real-time SSE endpoint
app.get('/api/events/:projectId', (req, res) => {
  const { projectId } = req.params;
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });
  res.write('\n');

  if (!sseClients.has(projectId)) {
    sseClients.set(projectId, []);
  }
  sseClients.get(projectId).push(res);

  // Send current project state immediately if exists
  const current = pm.getProject(projectId);
  if (current) {
    res.write(`data: ${JSON.stringify({ projectId, step: current.step, stepName: current.stepName, status: current.status })}\n\n`);
  }

  req.on('close', () => {
    const list = sseClients.get(projectId) || [];
    sseClients.set(projectId, list.filter(c => c !== res));
  });
});

// List all projects
app.get('/api/projects', (req, res) => {
  res.json({ success: true, projects: pm.getAllProjects() });
});

// Get single project
app.get('/api/projects/:id', (req, res) => {
  const project = pm.getProject(req.params.id);
  if (!project) return res.status(404).json({ success: false, error: 'Project not found' });
  res.json({ success: true, project });
});

// Explore project workspace files
app.get('/api/projects/:id/files', (req, res) => {
  const project = pm.getProject(req.params.id);
  if (!project) return res.status(404).json({ success: false, error: 'Project not found' });

  try {
    const files = pm.readWorkspaceFiles(project.workspacePath);
    const fileList = Object.keys(files).map(filePath => {
      const isBuffer = Buffer.isBuffer(files[filePath]);
      return {
        path: filePath,
        isBinary: isBuffer,
        size: isBuffer ? files[filePath].length : Buffer.byteLength(files[filePath], 'utf8')
      };
    });
    res.json({ success: true, files: fileList });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Preview a single file content
app.get('/api/projects/:id/file', (req, res) => {
  const project = pm.getProject(req.params.id);
  if (!project) return res.status(404).json({ success: false, error: 'Project not found' });

  const targetRel = req.query.path;
  if (!targetRel) return res.status(400).json({ success: false, error: 'File path required' });

  const fullPath = path.join(project.workspacePath, targetRel);
  if (!fs.existsSync(fullPath)) return res.status(404).json({ success: false, error: 'File not found' });

  // Security check: ensure path is within workspace
  if (!fullPath.startsWith(project.workspacePath)) {
    return res.status(403).json({ success: false, error: 'Access denied' });
  }

  if (targetRel.endsWith('.png')) {
    res.setHeader('Content-Type', 'image/png');
    return fs.createReadStream(fullPath).pipe(res);
  } else if (targetRel.endsWith('.jpg') || targetRel.endsWith('.jpeg')) {
    res.setHeader('Content-Type', 'image/jpeg');
    return fs.createReadStream(fullPath).pipe(res);
  } else if (targetRel.endsWith('.ico')) {
    res.setHeader('Content-Type', 'image/x-icon');
    return fs.createReadStream(fullPath).pipe(res);
  } else {
    const content = fs.readFileSync(fullPath, 'utf8');
    res.type('text/plain').send(content);
  }
});

// Download verified ZIP archive
app.get('/api/projects/:id/download', (req, res) => {
  try {
    const project = pm.getProject(req.params.id);
    if (!project) return res.status(404).send('Project not found');
    if (!project.zipInfo || !project.zipInfo.zipPath) {
      return res.status(400).send('ZIP file has not been packaged yet');
    }

    const { zipPath, fileName } = project.zipInfo;
    if (!fs.existsSync(zipPath)) {
      return res.status(404).send('ZIP file missing on disk');
    }

    const stats = fs.statSync(zipPath);
    const safeFileName = path.basename(fileName).replace(/["']/g, '');

    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Length': stats.size,
      'Content-Disposition': `attachment; filename="${safeFileName}"`,
      'Cache-Control': 'no-cache'
    });

    const fileStream = fs.createReadStream(zipPath);
    fileStream.on('error', (err) => {
      console.error('File stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Error streaming download');
      }
    });

    fileStream.pipe(res);
  } catch (err) {
    console.error('Download handler exception:', err);
    if (!res.headersSent) {
      res.status(500).send('Download failed: ' + err.message);
    }
  }
});

// Test AI Provider Connection
app.post('/api/ai/test', async (req, res) => {
  const { provider, apiKey, model, endpoint } = req.body;
  if (provider === 'builtin') {
    return res.json({ success: true, message: 'Built-in Autonomous Engine is ready (100% offline, zero API keys required).' });
  }

  if (!apiKey && provider !== 'custom') {
    return res.status(400).json({ success: false, error: 'API key is required for external providers.' });
  }

  try {
    const ai = new AIService({ provider, apiKey, model, endpoint });
    const plan = await ai.generatePlan('wordpress_plugin', 'Quick health check ping test');
    res.json({
      success: true,
      message: `Successfully connected to ${provider.toUpperCase()} (${ai.model})!`,
      sample: plan.projectName
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Submit Requirement & Generate Project
app.post('/api/projects/generate', upload.array('files', 10), async (req, res) => {
  try {
    const {
      projectType = 'wordpress_theme',
      prompt,
      name,
      slug,
      referenceUrl,
      author,
      version,
      primaryColor,
      accentColor,
      aiProvider = 'builtin',
      aiApiKey,
      aiModel,
      aiEndpoint
    } = req.body;

    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ success: false, error: 'Please provide a project description or requirements.' });
    }

    // 1. Create isolated project record & workspace
    const project = pm.createProject({
      type: projectType,
      prompt,
      name,
      slug,
      referenceUrl,
      author,
      version,
      primaryColor,
      accentColor
    });

    // 2. Handle uploaded reference or existing ZIP files
    let existingZipExtracted = false;
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        const savedPath = pm.saveUploadedFile(project.id, file.buffer, file.originalname);
        // If an existing ZIP was uploaded, extract it to workspace for modification
        if (file.originalname.endsWith('.zip') && !existingZipExtracted) {
          pm.extractExistingZip(project.id, savedPath);
          existingZipExtracted = true;
        }
      }
    }

    const aiConfig = {
      provider: aiProvider,
      apiKey: aiApiKey || '',
      model: aiModel || '',
      endpoint: aiEndpoint || ''
    };

    // Return project immediately so frontend can open SSE connection
    res.json({
      success: true,
      projectId: project.id,
      project
    });

    // Run the 10-step autonomous workflow asynchronously
    setImmediate(async () => {
      try {
        await orchestrator.runWorkflow(project.id, aiConfig);
      } catch (err) {
        console.error(`Workflow execution failed for ${project.id}:`, err);
      }
    });

  } catch (err) {
    console.error('Project generation error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start Server
const server = app.listen(config.PORT, () => {
  console.log(`=======================================================`);
  console.log(` Autonomous WordPress & Shopify ZIP Generator Agent`);
  console.log(` Web Server running at: http://localhost:${config.PORT}`);
  console.log(` Workspaces: ${config.WORKSPACES_DIR}`);
  console.log(` Output ZIPs: ${config.DIST_DIR}`);
  console.log(`=======================================================`);
});

module.exports = { app, server, pm, orchestrator };
