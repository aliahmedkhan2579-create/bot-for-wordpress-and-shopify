/**
 * Autonomous CMS ZIP Generator Frontend Application
 */
document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // State
  let currentProjectId = null;
  let activeEventSource = null;
  let selectedFiles = [];
  let aiConfig = {
    provider: localStorage.getItem('agy_ai_provider') || 'builtin',
    apiKey: localStorage.getItem('agy_ai_key') || '',
    model: localStorage.getItem('agy_ai_model') || '',
    endpoint: localStorage.getItem('agy_ai_endpoint') || ''
  };

  // DOM Elements
  const form = document.getElementById('generatorForm');
  const generateBtn = document.getElementById('generateBtn');
  const typeCards = document.querySelectorAll('.type-card');
  const promptInput = document.getElementById('prompt');
  const fileDropzone = document.getElementById('fileDropzone');
  const fileInput = document.getElementById('fileInput');
  const fileListPreview = document.getElementById('fileListPreview');
  const primaryColorInput = document.getElementById('primaryColor');
  const primaryColorText = document.getElementById('primaryColorText');
  const accentColorInput = document.getElementById('accentColor');
  const accentColorText = document.getElementById('accentColorText');
  const currentAiProviderBadge = document.getElementById('currentAiProviderBadge');

  // Execution Monitor
  const agentStatusBadge = document.getElementById('agentStatusBadge');
  const agentIdleView = document.getElementById('agentIdleView');
  const agentActiveView = document.getElementById('agentActiveView');
  const downloadBanner = document.getElementById('downloadBanner');
  const downloadFileName = document.getElementById('downloadFileName');
  const downloadMeta = document.getElementById('downloadMeta');
  const downloadRealPath = document.getElementById('downloadRealPath');
  const downloadZipBtn = document.getElementById('downloadZipBtn');
  const workflowStepper = document.getElementById('workflowStepper');
  const agentConsole = document.getElementById('agentConsole');
  const validationList = document.getElementById('validationList');
  const planDetails = document.getElementById('planDetails');
  const fileTreeList = document.getElementById('fileTreeList');
  const codeViewer = document.getElementById('codeViewer');
  const previewFilePath = document.getElementById('previewFilePath');
  const workspaceFileCount = document.getElementById('workspaceFileCount');

  // Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  // History
  const historyTableBody = document.getElementById('historyTableBody');
  const refreshHistoryBtn = document.getElementById('refreshHistoryBtn');

  // AI Modal Elements
  const aiConfigBtn = document.getElementById('aiConfigBtn');
  const aiModal = document.getElementById('aiModal');
  const closeAiModalBtn = document.getElementById('closeAiModalBtn');
  const cancelAiModalBtn = document.getElementById('cancelAiModalBtn');
  const saveAiConfigBtn = document.getElementById('saveAiConfigBtn');
  const modalAiProvider = document.getElementById('modalAiProvider');
  const externalAiFields = document.getElementById('externalAiFields');
  const endpointGroup = document.getElementById('endpointGroup');
  const modalApiKey = document.getElementById('modalApiKey');
  const modalEndpoint = document.getElementById('modalEndpoint');
  const modalModel = document.getElementById('modalModel');
  const testAiConnectionBtn = document.getElementById('testAiConnectionBtn');
  const testConnectionStatus = document.getElementById('testConnectionStatus');

  // Presets definition
  const presets = {
    'wp-agency': {
      type: 'wordpress_theme',
      name: 'Vanguard Agency & E-Commerce',
      slug: 'vanguard-agency',
      prompt: 'A sleek, modern creative agency and portfolio WordPress theme with full WooCommerce store integration. Includes customizable hero sections, responsive case study grids, client testimonials slider, sticky navbar, mobile drawer menu, dynamic shopping cart drawer, and clean typography.'
    },
    'wp-plugin-leads': {
      type: 'wordpress_plugin',
      name: 'OmniLead AJAX Form & CPT',
      slug: 'omnilead-capture',
      prompt: 'A secure WordPress lead generation and contact form plugin. Features responsive AJAX submission with nonce verification, input sanitization, customizable admin settings panel under wp-admin, custom post type for lead records, shortcode [omnilead-capture], and a REST API status route.'
    },
    'shopify-store': {
      type: 'shopify_theme',
      name: 'Aura Artisan Goods OS 2.0',
      slug: 'aura-artisan-theme',
      prompt: 'A minimalist, high-converting Shopify Online Store 2.0 theme. Built with JSON templates for index, product, and collection pages. Features customizable announcement bar, hero section with call-to-action, featured products carousel, slide-out mini-cart drawer, customizer schema presets, and responsive CSS variables.'
    }
  };

  // 10 Standard Workflow Steps
  const workflowSteps = [
    { num: 1, name: 'Analyzing Requirements & Project Specifications' },
    { num: 2, name: 'Creating Internal Development Plan & Architecture' },
    { num: 3, name: 'Generating Complete Source Code & Project Assets' },
    { num: 4, name: 'Organizing Project Files into Directory Structure' },
    { num: 5, name: 'Implementing Specialized Features, Hooks & Styling' },
    { num: 6, name: 'Running Automatic Multi-Stage Code Validation' },
    { num: 7, name: 'Detecting and Applying Automated Error Fixes' },
    { num: 8, name: 'Repeating Verification & Quality Assurance Audit' },
    { num: 9, name: 'Packaging Installable Clean ZIP Archive' },
    { num: 10, name: 'Development Complete - ZIP Ready for Download' }
  ];

  // Initialize
  initUI();
  loadProjectHistory();

  function initUI() {
    updateAiBadge();

    // Type card selector
    typeCards.forEach(card => {
      card.addEventListener('click', () => {
        typeCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        const radio = card.querySelector('input');
        if (radio) radio.checked = true;
      });
    });

    // Preset pills
    document.querySelectorAll('.pill').forEach(pill => {
      pill.addEventListener('click', () => {
        const key = pill.dataset.preset;
        const preset = presets[key];
        if (preset) {
          promptInput.value = preset.prompt;
          document.getElementById('projectName').value = preset.name;
          document.getElementById('projectSlug').value = preset.slug;

          typeCards.forEach(card => {
            if (card.dataset.type === preset.type) {
              card.click();
            }
          });
        }
      });
    });

    // Color Pickers
    primaryColorInput.addEventListener('input', (e) => {
      primaryColorText.textContent = e.target.value;
    });
    accentColorInput.addEventListener('input', (e) => {
      accentColorText.textContent = e.target.value;
    });

    // Dropzone
    fileDropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      fileDropzone.classList.add('dragover');
    });
    fileDropzone.addEventListener('dragleave', () => {
      fileDropzone.classList.remove('dragover');
    });
    fileDropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      fileDropzone.classList.remove('dragover');
      if (e.dataTransfer.files) {
        handleFiles(e.dataTransfer.files);
      }
    });
    fileInput.addEventListener('change', (e) => {
      if (e.target.files) handleFiles(e.target.files);
    });

    // Tabs
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        const target = document.getElementById(btn.dataset.tab);
        if (target) target.classList.add('active');
      });
    });

    // History refresh
    refreshHistoryBtn.addEventListener('click', loadProjectHistory);

    // AI Modal handlers
    aiConfigBtn.addEventListener('click', openAiModal);
    closeAiModalBtn.addEventListener('click', closeAiModal);
    cancelAiModalBtn.addEventListener('click', closeAiModal);
    modalAiProvider.addEventListener('change', toggleAiModalFields);
    saveAiConfigBtn.addEventListener('click', saveAiConfig);
    testAiConnectionBtn.addEventListener('click', testAiConnection);

    // Form submit
    form.addEventListener('submit', handleFormSubmit);
  }

  function handleFiles(files) {
    selectedFiles = Array.from(files);
    fileListPreview.innerHTML = '';
    selectedFiles.forEach((f, idx) => {
      const item = document.createElement('div');
      item.className = 'file-preview-item';
      item.innerHTML = `
        <span>📄 <strong>${escapeHtml(f.name)}</strong> (${(f.size / 1024).toFixed(1)} KB)</span>
        <button type="button" class="btn btn-outline btn-small" style="padding: 2px 6px;" data-idx="${idx}">✕</button>
      `;
      item.querySelector('button').addEventListener('click', () => {
        selectedFiles.splice(idx, 1);
        handleFiles(selectedFiles);
      });
      fileListPreview.appendChild(item);
    });
  }

  function updateAiBadge() {
    const prov = aiConfig.provider;
    if (prov === 'builtin') {
      currentAiProviderBadge.textContent = 'Built-in (Zero-Config)';
      currentAiProviderBadge.style.color = '#34d399';
    } else {
      currentAiProviderBadge.textContent = prov.toUpperCase();
      currentAiProviderBadge.style.color = '#60a5fa';
    }
  }

  function openAiModal() {
    modalAiProvider.value = aiConfig.provider;
    modalApiKey.value = aiConfig.apiKey;
    modalEndpoint.value = aiConfig.endpoint;
    modalModel.value = aiConfig.model;
    toggleAiModalFields();
    testConnectionStatus.textContent = '';
    aiModal.style.display = 'flex';
  }

  function closeAiModal() {
    aiModal.style.display = 'none';
  }

  function toggleAiModalFields() {
    const isBuiltin = modalAiProvider.value === 'builtin';
    const isCustom = modalAiProvider.value === 'custom';
    externalAiFields.style.display = isBuiltin ? 'none' : 'block';
    endpointGroup.style.display = isCustom ? 'block' : 'none';
  }

  async function testAiConnection() {
    testConnectionStatus.textContent = 'Testing connection...';
    testConnectionStatus.style.color = '#60a5fa';

    try {
      const res = await fetch('/api/ai/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: modalAiProvider.value,
          apiKey: modalApiKey.value,
          model: modalModel.value,
          endpoint: modalEndpoint.value
        })
      });
      const data = await res.json();
      if (data.success) {
        testConnectionStatus.textContent = '✓ ' + data.message;
        testConnectionStatus.style.color = '#34d399';
      } else {
        testConnectionStatus.textContent = '✗ ' + data.error;
        testConnectionStatus.style.color = '#f87171';
      }
    } catch (err) {
      testConnectionStatus.textContent = '✗ ' + err.message;
      testConnectionStatus.style.color = '#f87171';
    }
  }

  function saveAiConfig() {
    aiConfig = {
      provider: modalAiProvider.value,
      apiKey: modalApiKey.value.trim(),
      endpoint: modalEndpoint.value.trim(),
      model: modalModel.value.trim()
    };
    localStorage.setItem('agy_ai_provider', aiConfig.provider);
    localStorage.setItem('agy_ai_key', aiConfig.apiKey);
    localStorage.setItem('agy_ai_endpoint', aiConfig.endpoint);
    localStorage.setItem('agy_ai_model', aiConfig.model);

    updateAiBadge();
    closeAiModal();
  }

  async function handleFormSubmit(e) {
    e.preventDefault();

    const selectedType = document.querySelector('input[name="projectType"]:checked')?.value || 'wordpress_theme';
    const prompt = promptInput.value.trim();

    if (!prompt) {
      alert('Please describe your requirements.');
      return;
    }

    generateBtn.disabled = true;
    generateBtn.querySelector('.btn-text').textContent = 'Starting Autonomous Pipeline...';

    // Build FormData
    const formData = new FormData();
    formData.append('projectType', selectedType);
    formData.append('prompt', prompt);
    formData.append('name', document.getElementById('projectName').value.trim());
    formData.append('slug', document.getElementById('projectSlug').value.trim());
    formData.append('referenceUrl', document.getElementById('referenceUrl').value.trim());
    formData.append('primaryColor', primaryColorInput.value);
    formData.append('accentColor', accentColorInput.value);

    // AI Config
    formData.append('aiProvider', aiConfig.provider);
    formData.append('aiApiKey', aiConfig.apiKey);
    formData.append('aiModel', aiConfig.model);
    formData.append('aiEndpoint', aiConfig.endpoint);

    // Files
    selectedFiles.forEach(f => {
      formData.append('files', f);
    });

    try {
      const res = await fetch('/api/projects/generate', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to initialize project generation');
      }

      currentProjectId = data.projectId;

      // Switch to active view
      agentIdleView.style.display = 'none';
      agentActiveView.style.display = 'block';
      downloadBanner.style.display = 'none';
      agentConsole.innerHTML = '';
      renderStepper(1);

      updateStatusBadge('running', 'Synthesizing Architecture & Code...');
      addConsoleLine(`[Agent] Initialized session for project ID: ${currentProjectId}`, 'info');

      // Listen for real-time progress events
      listenToEvents(currentProjectId);

    } catch (err) {
      alert('Error launching project generation: ' + err.message);
      generateBtn.disabled = false;
      generateBtn.querySelector('.btn-text').textContent = 'Generate Complete Project ZIP';
    }
  }

  function renderStepper(currentStep) {
    workflowStepper.innerHTML = '';
    workflowSteps.forEach(s => {
      const item = document.createElement('div');
      item.className = 'step-item';
      if (s.num < currentStep) item.classList.add('done');
      if (s.num === currentStep) item.classList.add('active');

      item.innerHTML = `
        <div class="step-num">${s.num < currentStep ? '✓' : s.num}</div>
        <div class="step-title">${s.num}. ${s.name}</div>
      `;
      workflowStepper.appendChild(item);
    });
  }

  function updateStatusBadge(status, text) {
    agentStatusBadge.className = `status-indicator-badge ${status}`;
    agentStatusBadge.querySelector('.status-text').textContent = text;
  }

  function addConsoleLine(text, type = '') {
    const line = document.createElement('div');
    line.className = `console-line ${type}`;
    const time = new Date().toLocaleTimeString();
    line.textContent = `[${time}] ${text}`;
    agentConsole.appendChild(line);
    agentConsole.scrollTop = agentConsole.scrollHeight;
  }

  function listenToEvents(projectId) {
    if (activeEventSource) {
      activeEventSource.close();
    }

    activeEventSource = new EventSource(`/api/events/${projectId}`);

    activeEventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.step) {
          renderStepper(data.step);
        }

        if (data.message) {
          addConsoleLine(data.message, data.step === 10 ? 'success' : (data.step === -1 ? 'error' : ''));
        }

        // Project Finished (Step 10)
        if (data.step === 10) {
          updateStatusBadge('completed', 'ZIP Packaging Verified & Ready');
          generateBtn.disabled = false;
          generateBtn.querySelector('.btn-text').textContent = 'Generate Another Project ZIP';

          // Show download banner
          if (data.zipInfo) {
            downloadFileName.textContent = data.zipInfo.fileName;
            downloadMeta.textContent = `Verified Archive • ${data.zipInfo.fileCount} Files • ${data.zipInfo.fileSizeFormatted}`;
            downloadRealPath.textContent = data.zipInfo.zipPath;
            downloadZipBtn.href = `/api/projects/${projectId}/download`;
            downloadBanner.style.display = 'flex';
          }

          // Fetch full project details to populate tabs
          loadProjectDetails(projectId);
          loadProjectHistory();
        }

        // Project Failed
        if (data.step === -1) {
          updateStatusBadge('failed', 'Generation Error');
          generateBtn.disabled = false;
          generateBtn.querySelector('.btn-text').textContent = 'Retry Generation';
          loadProjectHistory();
        }

      } catch (err) {
        console.error('SSE parse error:', err);
      }
    };

    activeEventSource.onerror = () => {
      // Stream closed or error
    };
  }

  async function loadProjectDetails(projectId) {
    try {
      const res = await fetch(`/api/projects/${projectId}`);
      const data = await res.json();
      if (!data.success) return;

      const project = data.project;

      // 1. Validation Report
      renderValidationReport(project.validationReport || []);

      // 2. Plan Details
      renderPlanDetails(project.plan);

      // 3. Workspace Files Tree
      loadWorkspaceFiles(projectId);

    } catch (err) {
      console.error('Error fetching project details:', err);
    }
  }

  function renderValidationReport(tests) {
    validationList.innerHTML = '';
    if (!tests || tests.length === 0) {
      validationList.innerHTML = '<p class="text-muted">No validation tests available.</p>';
      return;
    }

    tests.forEach(t => {
      const card = document.createElement('div');
      card.className = 'val-card';
      const badgeClass = t.status === 'passed' ? 'passed' : (t.status === 'unexecuted' ? 'unexecuted' : 'failed');
      const badgeText = t.status === 'passed' ? 'PASSED' : (t.status === 'unexecuted' ? 'OPTIONAL (SKIPPED)' : 'FAILED');

      card.innerHTML = `
        <div class="val-card-left">
          <div class="val-card-title">${escapeHtml(t.name)}</div>
          <div class="val-card-details">${escapeHtml(t.details || '')}</div>
        </div>
        <div class="val-badge ${badgeClass}">${badgeText}</div>
      `;
      validationList.appendChild(card);
    });
  }

  function renderPlanDetails(plan) {
    if (!plan) {
      planDetails.innerHTML = '<p class="text-muted">Architecture plan not available.</p>';
      return;
    }

    let manifestHtml = '';
    if (plan.manifest && plan.manifest.length > 0) {
      manifestHtml = `
        <div style="margin-top: 16px;">
          <h4 style="margin: 0 0 8px; font-size: 13px;">File Manifest (${plan.manifest.length} Files):</h4>
          <div style="max-height: 180px; overflow-y: auto; background: #0b0f19; padding: 10px; border-radius: 6px; font-size: 12px; font-family: var(--font-mono);">
            ${plan.manifest.map(m => `<div><strong>${escapeHtml(m.path)}</strong> <span style="color:#64748b;">— ${escapeHtml(m.purpose)}</span></div>`).join('')}
          </div>
        </div>
      `;
    }

    planDetails.innerHTML = `
      <div style="background: #0b0f19; border: 1px solid #1f2937; border-radius: 8px; padding: 16px;">
        <h3 style="margin: 0 0 6px; font-size: 16px; color: #60a5fa;">${escapeHtml(plan.projectName || '')}</h3>
        <p style="margin: 0 0 10px; font-size: 13px; color: #94a3b8;"><strong>Architecture:</strong> ${escapeHtml(plan.architecture || '')}</p>
        <p style="margin: 0; font-size: 13px; color: #cbd5e1;">${escapeHtml(plan.description || '')}</p>
        ${manifestHtml}
      </div>
    `;
  }

  async function loadWorkspaceFiles(projectId) {
    try {
      const res = await fetch(`/api/projects/${projectId}/files`);
      const data = await res.json();
      if (!data.success) return;

      const files = data.files || [];
      workspaceFileCount.textContent = files.length;
      fileTreeList.innerHTML = '';

      if (files.length === 0) {
        fileTreeList.innerHTML = '<div class="text-muted text-center" style="padding: 12px;">No files found</div>';
        return;
      }

      files.forEach((f, idx) => {
        const item = document.createElement('div');
        item.className = 'tree-item';
        if (idx === 0) item.classList.add('selected');
        item.textContent = f.path;
        item.title = f.path;

        item.addEventListener('click', () => {
          document.querySelectorAll('.tree-item').forEach(i => i.classList.remove('selected'));
          item.classList.add('selected');
          fetchAndPreviewFile(projectId, f.path, f.isBinary);
        });

        fileTreeList.appendChild(item);
      });

      // Preview first file by default
      if (files[0]) {
        fetchAndPreviewFile(projectId, files[0].path, files[0].isBinary);
      }

    } catch (err) {
      console.error('Error loading files:', err);
    }
  }

  async function fetchAndPreviewFile(projectId, filePath, isBinary) {
    previewFilePath.textContent = filePath;
    if (isBinary) {
      codeViewer.textContent = `[Binary file: ${(filePath.endsWith('.png') ? 'PNG Image' : 'Asset')}] Preview not available as text.`;
      return;
    }

    try {
      const res = await fetch(`/api/projects/${projectId}/file?path=${encodeURIComponent(filePath)}`);
      if (res.ok) {
        const text = await res.text();
        codeViewer.textContent = text;
      } else {
        codeViewer.textContent = '// Failed to load file content';
      }
    } catch (err) {
      codeViewer.textContent = '// Error reading file: ' + err.message;
    }
  }

  async function loadProjectHistory() {
    try {
      const res = await fetch('/api/projects');
      const data = await res.json();
      if (!data.success) return;

      const projects = data.projects || [];
      historyTableBody.innerHTML = '';

      if (projects.length === 0) {
        historyTableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted" style="padding: 24px;">No projects generated yet.</td></tr>`;
        return;
      }

      projects.forEach(p => {
        const tr = document.createElement('tr');
        const dateStr = new Date(p.createdAt).toLocaleDateString() + ' ' + new Date(p.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const typeLabel = p.type === 'wordpress_theme' ? 'WP Theme' : (p.type === 'wordpress_plugin' ? 'WP Plugin' : 'Shopify Theme');

        let statusClass = p.status === 'completed' ? 'success' : (p.status === 'running' ? 'info' : 'danger');

        tr.innerHTML = `
          <td><strong>${escapeHtml(p.name)}</strong><br><span style="font-size:11px;color:#6b7280;">${escapeHtml(p.slug)}</span></td>
          <td><span class="pill" style="font-size:11px;">${typeLabel}</span></td>
          <td><span class="status-indicator-badge ${p.status}" style="font-size:11px;">${p.status.toUpperCase()}</span></td>
          <td style="color:#9ca3af;font-size:12px;">${dateStr}</td>
          <td>${p.zipInfo ? `<code>${escapeHtml(p.zipInfo.fileName)}</code> (${p.zipInfo.fileSizeFormatted})` : '<span style="color:#6b7280;">N/A</span>'}</td>
          <td>
            <div style="display: flex; gap: 8px;">
              ${p.zipInfo ? `<a href="/api/projects/${p.id}/download" class="btn btn-outline btn-small" download>⬇️ Download</a>` : ''}
              <button type="button" class="btn btn-outline btn-small inspect-btn" data-id="${p.id}">Inspect</button>
            </div>
          </td>
        `;

        tr.querySelector('.inspect-btn')?.addEventListener('click', () => {
          currentProjectId = p.id;
          agentIdleView.style.display = 'none';
          agentActiveView.style.display = 'block';

          if (p.zipInfo) {
            downloadFileName.textContent = p.zipInfo.fileName;
            downloadMeta.textContent = `Verified Archive • ${p.zipInfo.fileCount} Files • ${p.zipInfo.fileSizeFormatted}`;
            downloadRealPath.textContent = p.zipInfo.zipPath;
            downloadZipBtn.href = `/api/projects/${p.id}/download`;
            downloadBanner.style.display = 'flex';
          }

          renderStepper(p.step || 10);
          updateStatusBadge(p.status, p.status === 'completed' ? 'Ready for Download' : p.status);
          loadProjectDetails(p.id);

          window.scrollTo({ top: 300, behavior: 'smooth' });
        });

        historyTableBody.appendChild(tr);
      });

    } catch (err) {
      console.error('Error fetching history:', err);
    }
  }

  function escapeHtml(text) {
    if (!text) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});
