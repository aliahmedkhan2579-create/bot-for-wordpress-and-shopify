=== Untitled Project ===
Contributors: Autonomous AI Agent
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

# REAL-WORLD TEST: Build a Complete WordPress Plugin and Deliver a ZIP

I want to test whether my AI WordPress & Shopify development agent actually works. Do not just explain how you would build a plugin. Use the agent's real development, file creation, testing, and ZIP packaging workflow.

## Project: Smart Contact Form Pro

Build a complete WordPress plugin named "Smart Contact Form Pro".

Plugin slug: smart-contact-form-pro

Main plugin file: smart-contact-form-pro.php

### 1. Required Features

Create a professional contact form with these fields:
- Full Name (required)
- Email Address (required and validated)
- Subject (required)
- Message (required)
- Submit button

Additional functionality:
- Provide a shortcode: [smart_contact_form]
- Allow the form to be displayed on any WordPress page or post.
- Display a success message after successful submission.
- Display useful validation and error messages.
- Save submitted messages in the WordPress database.
- Add a "Contact Messages" menu to the WordPress admin dashboard.
- Allow administrators to view saved messages, including name, email, subject, message, and submission date.
- Add a settings page where the administrator can configure the notification recipient email.
- Send an email notification to the configured recipient when a valid message is submitted.
- Use a responsive, professional design suitable for desktop and mobile.
- Include basic spam protection using WordPress nonces and a honeypot field.

### 2. Security Requirements

Use WordPress APIs and follow WordPress security best practices.

- Sanitize all submitted data.
- Validate email addresses.
- Escape displayed data.
- Verify nonces on form submissions.
- Check administrator capabilities before displaying or modifying admin data.
- Use prepared database queries where appropriate.
- Prevent unauthorized access to contact messages.
- Never expose sensitive information.

### 3. Required Plugin Files

Create a complete project with all necessary files, such as:

- smart-contact-form-pro.php
- includes/ (if needed)
- assets/css/style.css
- assets/js/script.js (only if needed)
- readme.txt
- uninstall.php (only if necessary)

You may use a different internal structure if technically appropriate, but the plugin must be complete and installable.

### 4. Mandatory Testing

Before delivery:

1. Check that all required files exist.
2. Run PHP syntax checks if PHP is available.
3. Validate the main plugin header.
4. Inspect the database table creation and activation logic.
5. Check shortcode registration.
6. Inspect form validation, nonce verification, and spam protection.
7. Check admin capability restrictions and output escaping.
8. Check email notification handling and error handling.
9. Run any available automated tests.
10. Fix detected errors and rerun the relevant checks.

If a real WordPress installation is available, test activation, form submission, database storage, admin message viewing, and email behavior.

If WordPress is not available, perform all possible static checks and clearly identify which features remain untested. Do not pretend a feature works simply because its code exists.

### 5. Mandatory ZIP Delivery

Create this file:

smart-contact-form-pro.zip

The ZIP must contain the folder:

smart-contact-form-pro/

Inside that folder, include the main PHP plugin file and all required files.

After creating the ZIP:
- Verify that the ZIP exists and opens successfully.
- Verify that the correct folder structure is present.
- Confirm that the main plugin file exists inside the ZIP.
- Check for missing dependencies and unnecessary files.
- Provide the actual downloadable ZIP file and its exact output path.

### 6. Final Report

When finished, report:

1. Whether the plugin was generated successfully.
2. The actual location of the ZIP file.
3. Whether the ZIP passed integrity and structure checks.
4. Which syntax and automated tests passed or failed.
5. Whether the plugin was tested inside a real WordPress installation.
6. Any remaining limitations.

IMPORTANT: Do not stop at a plan, sample code, or README. Actually create the plugin files, run the available checks, package the ZIP, and provide the download link.

Start now and use the existing AI agent workflow being tested.

== Description ==
Untitled Project is a high-performance, responsive WordPress theme designed with clean architecture, accessible HTML5 markup, and mobile-first styles.

== Installation ==
1. In your WordPress admin panel, go to Appearance > Themes and click "Add New".
2. Click "Upload Theme" and choose the generated `custom-project.zip` file.
3. Click "Install Now" and once installed, click "Activate".
4. Navigate to Appearance > Menus to configure primary and footer menus.

== Frequently Asked Questions ==
= Is this theme translation-ready? =
Yes! It supports full i18n localization with text-domain `custom-project`.

= Does it support WooCommerce? =
Yes, WooCommerce support and styles are fully bundled.

== Changelog ==
= 1.0.0 =
* Initial production release.
