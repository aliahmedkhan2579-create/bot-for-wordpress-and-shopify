<?php
/**
 * The template for displaying WooCommerce pages
 *
 * @package custom-project
 */

get_header();
?>

<div class="content-area woocommerce-area">
    <?php woocommerce_content(); ?>
</div>

<?php
get_footer();
