<?php
/**
 * The template for displaying search results pages
 *
 * @package custom-project
 */

get_header();
?>

<div class="content-area">
    <?php if (have_posts()) : ?>
        <header class="page-header search-header">
            <h1 class="page-title">
                <?php
                /* translators: %s: search query. */
                printf(esc_html__('Search Results for: %s', 'custom-project'), '<span>' . get_search_query() . '</span>');
                ?>
            </h1>
        </header>

        <div class="posts-grid">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/content', 'search');
            endwhile;
            ?>
        </div>

        <?php
        the_posts_pagination(array(
            'prev_text' => '&larr; ' . esc_html__('Previous', 'custom-project'),
            'next_text' => esc_html__('Next', 'custom-project') . ' &rarr;',
        ));
    else :
        get_template_part('template-parts/content', 'none');
    endif;
    ?>
</div>

<?php
get_footer();
