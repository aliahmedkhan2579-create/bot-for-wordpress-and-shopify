<?php
/**
 * The template for displaying all single posts
 *
 * @package custom-project
 */

get_header();
?>

<div class="content-area single-post-area">
    <?php
    while (have_posts()) :
        the_post();
        get_template_part('template-parts/content', 'single');

        the_post_navigation(array(
            'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'custom-project') . '</span> <span class="nav-title">%title</span>',
            'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'custom-project') . '</span> <span class="nav-title">%title</span>',
        ));

        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
    endwhile;
    ?>
</div>

<?php
if (is_active_sidebar('sidebar-1')) {
    get_sidebar();
}
get_footer();
