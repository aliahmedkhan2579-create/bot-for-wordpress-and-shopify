<?php
/**
 * The template for displaying archive pages
 *
 * @package custom-project
 */

get_header();
?>

<div class="content-area">
    <?php if (have_posts()) : ?>
        <header class="archive-header">
            <?php
            the_archive_title('<h1 class="archive-title">', '</h1>');
            the_archive_description('<div class="archive-description">', '</div>');
            ?>
        </header>

        <div class="posts-grid">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/content', get_post_type());
            endwhile;
            ?>
        </div>

        <?php
        the_posts_pagination(array(
            'prev_text' => '&larr; ' . esc_html__('Previous', 'custom-project'),
            'next_text' => esc_html__('Next', 'custom-project') . ' &rarr;',
        ));
    else :
        get_template_part('template-parts/content', 'none');
    endif;
    ?>
</div>

<?php
if (is_active_sidebar('sidebar-1')) {
    get_sidebar();
}
get_footer();
