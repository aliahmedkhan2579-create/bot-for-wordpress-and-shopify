<?php
/**
 * Untitled Project functions and definitions
 *
 * @package custom-project
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('CUSTOM_PROJECT_VERSION', '1.0.0');

if (!function_exists('custom_project_setup')) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     */
    function custom_project_setup() {
        // Make theme available for translation.
        load_theme_textdomain('custom-project', get_template_directory() . '/languages');

        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');

        // Let WordPress manage the document title.
        add_theme_support('title-tag');

        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support('post-thumbnails');
        set_post_thumbnail_size(1200, 675, true);

        // Register Primary and Footer navigation menus
        register_nav_menus(array(
            'primary' => esc_html__('Primary Menu', 'custom-project'),
            'footer'  => esc_html__('Footer Menu', 'custom-project'),
        ));

        // Switch default core markup to output valid HTML5
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ));

        // Set up the WordPress core custom background & logo feature.
        add_theme_support('custom-logo', array(
            'height'      => 80,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        ));

        // Gutenberg & Block Editor Support
        add_theme_support('align-wide');
        add_theme_support('responsive-embeds');
        add_theme_support('editor-styles');
        add_editor_style('assets/css/main.css');

        
        // WooCommerce Support
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
        
    }
endif;
add_action('after_setup_theme', 'custom_project_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 */
function custom_project_content_width() {
    $GLOBALS['content_width'] = apply_filters('custom_project_content_width', 1200);
}
add_action('after_setup_theme', 'custom_project_content_width', 0);

/**
 * Register widget area.
 */
function custom_project_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Sidebar', 'custom-project'),
        'id'            => 'sidebar-1',
        'description'   => esc_html__('Add widgets here to appear in your sidebar.', 'custom-project'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Area', 'custom-project'),
        'id'            => 'sidebar-footer',
        'description'   => esc_html__('Add widgets here to appear in the footer.', 'custom-project'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer-widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'custom_project_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function custom_project_scripts() {
    wp_enqueue_style('custom-project-style', get_stylesheet_uri(), array(), CUSTOM_PROJECT_VERSION);
    wp_enqueue_style('custom-project-main', get_template_directory_uri() . '/assets/css/main.css', array(), CUSTOM_PROJECT_VERSION);

    wp_enqueue_script('custom-project-main', get_template_directory_uri() . '/assets/js/main.js', array(), CUSTOM_PROJECT_VERSION, true);

    wp_localize_script('custom-project-main', 'custom_project_vars', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('custom-project_nonce'),
    ));

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'custom_project_scripts');
