<?php
/**
 * Template part for displaying single post content
 *
 * @package custom-project
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('entry-single'); ?>>
    <header class="entry-header">
        <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
        <div class="entry-meta">
            <span class="posted-on"><time class="entry-date published" datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time></span>
            <span class="byline"> <?php esc_html_e('by', 'custom-project'); ?> <span class="author vcard"><?php the_author_posts_link(); ?></span></span>
            <?php if (has_category()) : ?>
                <span class="cat-links"> <?php esc_html_e('in', 'custom-project'); ?> <?php the_category(', '); ?></span>
            <?php endif; ?>
        </div>
    </header>

    <?php if (has_post_thumbnail()) : ?>
        <div class="entry-featured-image">
            <?php the_post_thumbnail('large'); ?>
        </div>
    <?php endif; ?>

    <div class="entry-content">
        <?php
        the_content();

        wp_link_pages(array(
            'before' => '<div class="page-links">' . esc_html__('Pages:', 'custom-project'),
            'after'  => '</div>',
        ));
        ?>
    </div>

    <footer class="entry-footer">
        <?php the_tags('<div class="tags-links"><span class="tags-title">' . esc_html__('Tags:', 'custom-project') . '</span> ', ', ', '</div>'); ?>
    </footer>
</article>
