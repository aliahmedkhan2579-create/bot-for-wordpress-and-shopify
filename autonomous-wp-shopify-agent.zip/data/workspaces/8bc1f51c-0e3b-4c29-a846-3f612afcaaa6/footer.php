    </main><!-- #primary -->

    <footer id="colophon" class="site-footer">
        <?php if (is_active_sidebar('sidebar-footer')) : ?>
            <div class="footer-widgets-area container">
                <?php dynamic_sidebar('sidebar-footer'); ?>
            </div>
        <?php endif; ?>

        <div class="site-info container">
            <p>&copy; <?php echo esc_html(date_i18n('Y')); ?> <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>. <?php esc_html_e('All rights reserved.', 'custom-project'); ?></p>
            <p class="powered-by"><?php printf(esc_html__('Powered by %s and %s', 'custom-project'), '<a href="https://wordpress.org/">WordPress</a>', 'Untitled Project'); ?></p>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
