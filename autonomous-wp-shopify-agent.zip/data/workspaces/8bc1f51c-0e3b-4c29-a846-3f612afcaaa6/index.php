<?php
/**
 * The main template file
 *
 * @package custom-project
 */

get_header();
?>

<div class="content-area">
    <?php
    if (have_posts()) :
        if (is_home() && !is_front_page()) :
            ?>
            <header class="page-header">
                <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
            </header>
            <?php
        endif;

        echo '<div class="posts-grid">';
        while (have_posts()) :
            the_post();
            get_template_part('template-parts/content', get_post_type());
        endwhile;
        echo '</div>';

        the_posts_pagination(array(
            'prev_text' => '&larr; ' . esc_html__('Previous', 'custom-project'),
            'next_text' => esc_html__('Next', 'custom-project') . ' &rarr;',
        ));
    else :
        get_template_part('template-parts/content', 'none');
    endif;
    ?>
</div>

<?php
if (is_active_sidebar('sidebar-1')) {
    get_sidebar();
}
get_footer();
