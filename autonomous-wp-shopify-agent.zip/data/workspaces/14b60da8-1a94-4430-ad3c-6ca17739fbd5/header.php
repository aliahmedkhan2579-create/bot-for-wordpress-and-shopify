<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site-wrapper">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'vanguard-agency'); ?></a>

    <header id="masthead" class="site-header">
        <div class="header-inner container">
            <div class="site-branding">
                <?php
                if (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    ?>
                    <h1 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></h1>
                    <?php
                    $description = get_bloginfo('description', 'display');
                    if ($description || is_customize_preview()) {
                        echo '<p class="site-description">' . esc_html($description) . '</p>';
                    }
                }
                ?>
            </div>

            <nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e('Primary Menu', 'vanguard-agency'); ?>">
                <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                    <span class="hamburger"></span>
                    <span class="screen-reader-text"><?php esc_html_e('Toggle Menu', 'vanguard-agency'); ?></span>
                </button>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_id'        => 'primary-menu',
                    'container_class'=> 'primary-menu-container',
                    'fallback_cb'    => function() {
                        echo '<ul id="primary-menu" class="nav-menu"><li><a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'vanguard-agency') . '</a></li></ul>';
                    }
                ));
                ?>
            </nav>

            
            <div class="header-commerce">
                <a class="cart-customlocation" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="<?php esc_attr_e('View your shopping cart', 'vanguard-agency'); ?>">
                    <span class="cart-icon">&#128722;</span>
                    <span class="cart-count"><?php echo WC()->cart ? esc_html(WC()->cart->get_cart_contents_count()) : '0'; ?></span>
                </a>
            </div>
            
        </div>
    </header>

    <main id="primary" class="site-main container">
