<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package vanguard-agency
 */

get_header();
?>

<div class="content-area error-404 not-found">
    <header class="page-header text-center">
        <h1 class="page-title">404</h1>
        <h2><?php esc_html_e('Oops! That page can&rsquo;t be found.', 'vanguard-agency'); ?></h2>
    </header>

    <div class="page-content text-center">
        <p><?php esc_html_e('It looks like nothing was found at this location. Maybe try a search or check the home page?', 'vanguard-agency'); ?></p>
        <div class="error-search-box">
            <?php get_search_form(); ?>
        </div>
        <p><a href="<?php echo esc_url(home_url('/')); ?>" class="btn-primary"><?php esc_html_e('Return to Home', 'vanguard-agency'); ?></a></p>
    </div>
</div>

<?php
get_footer();
