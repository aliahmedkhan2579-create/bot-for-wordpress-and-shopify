/**
 * Shopify Online Store 2.0 Theme Interactive Scripts
 */
document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // Cart Drawer open/close handler
  var drawer = document.getElementById('CartDrawer');
  var openBtns = document.querySelectorAll('.cart-toggle-btn');
  var closeBtns = document.querySelectorAll('[data-drawer-close]');

  function openDrawer() {
    if (drawer) {
      drawer.classList.add('is-open');
      drawer.setAttribute('aria-hidden', 'false');
    }
  }

  function closeDrawer() {
    if (drawer) {
      drawer.classList.remove('is-open');
      drawer.setAttribute('aria-hidden', 'true');
    }
  }

  openBtns.forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      openDrawer();
    });
  });

  closeBtns.forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      closeDrawer();
    });
  });

  // Variant selector handler
  var variantSelector = document.getElementById('SingleOptionSelector-0');
  var productForm = document.getElementById('product-form');
  if (variantSelector && productForm) {
    variantSelector.addEventListener('change', function () {
      var idInput = productForm.querySelector('input[name="id"]');
      if (idInput) {
        idInput.value = this.value;
      }
    });
  }
});
