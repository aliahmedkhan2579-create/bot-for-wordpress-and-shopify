# Shopify Online Store 2.0 Feature & App Guidelines

This theme is built natively for Shopify Online Store 2.0 with JSON templates and customizable section schema blocks.

### Built-in Native Features:
- Dynamic Section Reordering in Shopify Theme Customizer.
- Responsive Product Cards & Price Formatters.
- Sliding Cart Drawer & Line Items Summary.
- Customizer Colors, Fonts & Announcement Bar Settings.

### Features Requiring Shopify Apps or API Credentials:
If your requirements involve any of the following features, Shopify architecture requires dedicated apps rather than theme-only code:
1. **Recurring Subscriptions & Recharge Billing**:
   - Requires a certified subscription app (e.g., *Shopify Subscriptions*, *Recharge*, or *Appstle*). Shopify handles checkout tokenization only through subscription contracts.
2. **Customer Reviews & UGC Photos**:
   - Requires a reviews app (e.g., *Judge.me*, *Yotpo*, or *Loox*). Themes integrate review widgets via **App Blocks** in JSON templates.
3. **Complex Custom ERP / Warehouse Inventory Sync**:
   - Requires Shopify Admin REST or GraphQL API credentials configured through a custom Shopify App or private integration.
4. **Custom Checkout Step Fields (Shopify Plus)**:
   - Modifying checkout pages beyond standard branding requires **Shopify Plus** and **Checkout UI Extensions**.

To install this theme:
1. In Shopify Admin, navigate to **Online Store > Themes**.
2. Click **Add theme > Upload zip file**.
3. Select `aura-artisan-theme.zip` and click **Upload**.
4. Once uploaded, click **Customize** to tailor your sections or **Publish** to make it live!
