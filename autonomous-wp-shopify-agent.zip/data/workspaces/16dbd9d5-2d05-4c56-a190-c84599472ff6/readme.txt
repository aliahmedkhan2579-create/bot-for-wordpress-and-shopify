=== Vanguard Agency & E-Commerce ===
Contributors: Autonomous AI Agent
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A sleek, modern creative agency and portfolio WordPress theme with full WooCommerce store integration. Includes customizable hero sections, responsive case study grids, client testimonials slider, sticky navbar, mobile drawer menu, dynamic shopping cart drawer, and clean typography.

== Description ==
Vanguard Agency & E-Commerce is a high-performance, responsive WordPress theme designed with clean architecture, accessible HTML5 markup, and mobile-first styles.

== Installation ==
1. In your WordPress admin panel, go to Appearance > Themes and click "Add New".
2. Click "Upload Theme" and choose the generated `vanguard-agency.zip` file.
3. Click "Install Now" and once installed, click "Activate".
4. Navigate to Appearance > Menus to configure primary and footer menus.

== Frequently Asked Questions ==
= Is this theme translation-ready? =
Yes! It supports full i18n localization with text-domain `vanguard-agency`.

= Does it support WooCommerce? =
Yes, WooCommerce support and styles are fully bundled.

== Changelog ==
= 1.0.0 =
* Initial production release.
