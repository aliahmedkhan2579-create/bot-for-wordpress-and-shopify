<?php
/**
 * Fired during plugin deactivation
 *
 * @package custom-project
 */

if (!defined('ABSPATH')) {
    exit;
}

class CustomProject_Deactivator {
    public static function deactivate() {
        // Flush rewrite rules on deactivation
        flush_rewrite_rules();
    }
}
