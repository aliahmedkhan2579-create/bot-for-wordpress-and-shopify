<?php
/**
 * Fired during plugin activation
 *
 * @package custom-project
 */

if (!defined('ABSPATH')) {
    exit;
}

class CustomProject_Activator {
    public static function activate() {
        // Set up default plugin options
        if (false === get_option('custom_project_settings')) {
            $default_settings = array(
                'enable_feature' => 1,
                'notify_email'   => get_option('admin_email'),
                'display_title'  => 'Untitled Project',
                'custom_message' => 'Thank you for interacting with our plugin!',
            );
            add_option('custom_project_settings', $default_settings);
        }

        // Flush rewrite rules for any registered custom post types / routes
        flush_rewrite_rules();
    }
}
