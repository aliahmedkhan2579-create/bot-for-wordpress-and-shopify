<?php
/**
 * Fired when the plugin is deleted.
 *
 * @package custom-project
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options created by the plugin
delete_option('custom_project_settings');
