<?php
/**
 * Provide a public-facing view for the plugin
 *
 * @package custom-project
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="custom-project-card" id="custom-project-container">
    <div class="custom-project-card-header">
        <h3 class="custom-project-title"><?php echo esc_html($title); ?></h3>
        <p class="custom-project-desc"><?php esc_html_e('Submit your information securely below.', 'custom-project'); ?></p>
    </div>

    <form class="custom-project-form" id="custom-project-form" method="post">
        <div class="custom-project-field-group">
            <label for="custom-project-user-name"><?php esc_html_e('Your Name', 'custom-project'); ?> <span class="required">*</span></label>
            <input type="text" id="custom-project-user-name" name="user_name" required placeholder="<?php esc_attr_e('Jane Doe', 'custom-project'); ?>" class="custom-project-input" />
        </div>

        <div class="custom-project-field-group">
            <label for="custom-project-user-email"><?php esc_html_e('Email Address', 'custom-project'); ?> <span class="required">*</span></label>
            <input type="email" id="custom-project-user-email" name="user_email" required placeholder="<?php esc_attr_e('jane@example.com', 'custom-project'); ?>" class="custom-project-input" />
        </div>

        <div class="custom-project-field-group">
            <label for="custom-project-message"><?php esc_html_e('Message / Inquiries', 'custom-project'); ?></label>
            <textarea id="custom-project-message" name="message" rows="3" placeholder="<?php esc_attr_e('Enter your message here...', 'custom-project'); ?>" class="custom-project-textarea"></textarea>
        </div>

        <div class="custom-project-actions">
            <button type="submit" class="custom-project-submit-btn">
                <span class="btn-text"><?php esc_html_e('Submit Now', 'custom-project'); ?></span>
                <span class="btn-spinner" style="display:none;">&#9696;</span>
            </button>
        </div>

        <div class="custom-project-response" style="display:none;" role="alert"></div>
    </form>
</div>
