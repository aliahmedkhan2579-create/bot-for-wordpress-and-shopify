(function($) {
    'use strict';

    $(document).ready(function() {
        var $form = $('#custom-project-form');
        var $response = $form.find('.custom-project-response');
        var $btn = $form.find('.custom-project-submit-btn');
        var $btnText = $btn.find('.btn-text');
        var $btnSpinner = $btn.find('.btn-spinner');

        $form.on('submit', function(e) {
            e.preventDefault();

            var data = {
                action: 'custom_project_submit',
                nonce: custom_project_ajax_obj.nonce,
                user_name: $('#custom-project-user-name').val(),
                user_email: $('#custom-project-user-email').val(),
                message: $('#custom-project-message').val()
            };

            $btn.prop('disabled', true);
            $btnSpinner.show();
            $response.hide().removeClass('success error');

            $.post(custom_project_ajax_obj.ajax_url, data)
                .done(function(res) {
                    $response.addClass('success').html(res.data.message).fadeIn();
                    $form[0].reset();
                })
                .fail(function(xhr) {
                    var errMsg = 'An unexpected error occurred. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errMsg = xhr.responseJSON.data.message;
                    }
                    $response.addClass('error').html(errMsg).fadeIn();
                })
                .always(function() {
                    $btn.prop('disabled', false);
                    $btnSpinner.hide();
                });
        });
    });
})(jQuery);
