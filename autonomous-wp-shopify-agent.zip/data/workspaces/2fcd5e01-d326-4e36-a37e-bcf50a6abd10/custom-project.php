<?php
/**
 * The plugin bootstrap file
 *
 * @package           custom-project
 *
 * @wordpress-plugin
 * Plugin Name:       Untitled Project
 * Plugin URI:        https://example.com/custom-project
 * Description:       # REAL-WORLD TEST: Build a Complete WordPress Plugin and Deliver a ZIP

I want to test whether my AI WordPress & Shopify development agent actually works. Do not just explain how you would build a plugin. Use the agent's real development, file creation, testing, and ZIP packaging workflow.

## Project: Smart Contact Form Pro

Build a complete WordPress plugin named "Smart Contact Form Pro".

Plugin slug: smart-contact-form-pro

Main plugin file: smart-contact-form-pro.php

### 1. Required Features

Create a professional contact form with these fields:
- Full Name (required)
- Email Address (required and validated)
- Subject (required)
- Message (required)
- Submit button

Additional functionality:
- Provide a shortcode: [smart_contact_form]
- Allow the form to be displayed on any WordPress page or post.
- Display a success message after successful submission.
- Display useful validation and error messages.
- Save submitted messages in the WordPress database.
- Add a "Contact Messages" menu to the WordPress admin dashboard.
- Allow administrators to view saved messages, including name, email, subject, message, and submission date.
- Add a settings page where the administrator can configure the notification recipient email.
- Send an email notification to the configured recipient when a valid message is submitted.
- Use a responsive, professional design suitable for desktop and mobile.
- Include basic spam protection using WordPress nonces and a honeypot field.

### 2. Security Requirements

Use WordPress APIs and follow WordPress security best practices.

- Sanitize all submitted data.
- Validate email addresses.
- Escape displayed data.
- Verify nonces on form submissions.
- Check administrator capabilities before displaying or modifying admin data.
- Use prepared database queries where appropriate.
- Prevent unauthorized access to contact messages.
- Never expose sensitive information.

### 3. Required Plugin Files

Create a complete project with all necessary files, such as:

- smart-contact-form-pro.php
- includes/ (if needed)
- assets/css/style.css
- assets/js/script.js (only if needed)
- readme.txt
- uninstall.php (only if necessary)

You may use a different internal structure if technically appropriate, but the plugin must be complete and installable.

### 4. Mandatory Testing

Before delivery:

1. Check that all required files exist.
2. Run PHP syntax checks if PHP is available.
3. Validate the main plugin header.
4. Inspect the database table creation and activation logic.
5. Check shortcode registration.
6. Inspect form validation, nonce verification, and spam protection.
7. Check admin capability restrictions and output escaping.
8. Check email notification handling and error handling.
9. Run any available automated tests.
10. Fix detected errors and rerun the relevant checks.

If a real WordPress installation is available, test activation, form submission, database storage, admin message viewing, and email behavior.

If WordPress is not available, perform all possible static checks and clearly identify which features remain untested. Do not pretend a feature works simply because its code exists.

### 5. Mandatory ZIP Delivery

Create this file:

smart-contact-form-pro.zip

The ZIP must contain the folder:

smart-contact-form-pro/

Inside that folder, include the main PHP plugin file and all required files.

After creating the ZIP:
- Verify that the ZIP exists and opens successfully.
- Verify that the correct folder structure is present.
- Confirm that the main plugin file exists inside the ZIP.
- Check for missing dependencies and unnecessary files.
- Provide the actual downloadable ZIP file and its exact output path.

### 6. Final Report

When finished, report:

1. Whether the plugin was generated successfully.
2. The actual location of the ZIP file.
3. Whether the ZIP passed integrity and structure checks.
4. Which syntax and automated tests passed or failed.
5. Whether the plugin was tested inside a real WordPress installation.
6. Any remaining limitations.

IMPORTANT: Do not stop at a plan, sample code, or README. Actually create the plugin files, run the available checks, package the ZIP, and provide the download link.

Start now and use the existing AI agent workflow being tested.
 * Version:           1.0.0
 * Author:            Autonomous AI Agent
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       custom-project
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('CUSTOM_PROJECT_VERSION', '1.0.0');
define('CUSTOM_PROJECT_PATH', plugin_dir_path(__FILE__));
define('CUSTOM_PROJECT_URL', plugin_dir_url(__FILE__));
define('CUSTOM_PROJECT_BASENAME', plugin_basename(__FILE__));

/**
 * The code that runs during plugin activation.
 */
function activate_custom_project() {
    require_once CUSTOM_PROJECT_PATH . 'includes/class-custom-project-activator.php';
    CustomProject_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_custom_project() {
    require_once CUSTOM_PROJECT_PATH . 'includes/class-custom-project-deactivator.php';
    CustomProject_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_custom_project');
register_deactivation_hook(__FILE__, 'deactivate_custom_project');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require_once CUSTOM_PROJECT_PATH . 'includes/class-custom-project.php';

/**
 * Begins execution of the plugin.
 */
function run_custom_project() {
    $plugin = new CustomProject();
    $plugin->run();
}
run_custom_project();
