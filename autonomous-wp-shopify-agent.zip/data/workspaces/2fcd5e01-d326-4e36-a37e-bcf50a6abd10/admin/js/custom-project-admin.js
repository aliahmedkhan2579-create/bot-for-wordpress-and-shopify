(function($) {
    'use strict';
    $(document).ready(function() {
        console.log('Untitled Project admin panel initialized.');
    });
})(jQuery);
