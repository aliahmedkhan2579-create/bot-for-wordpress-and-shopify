<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package custom-project
 */

if (!defined('ABSPATH')) {
    exit;
}

class CustomProject_Admin {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name . '-admin', CUSTOM_PROJECT_URL . 'admin/css/custom-project-admin.css', array(), $this->version, 'all');
    }

    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name . '-admin', CUSTOM_PROJECT_URL . 'admin/js/custom-project-admin.js', array('jquery'), $this->version, false);
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            esc_html__('Untitled Project Settings', 'custom-project'),
            esc_html__('Untitled Project', 'custom-project'),
            'manage_options',
            $this->plugin_name,
            array($this, 'display_plugin_setup_page'),
            'dashicons-admin-generic',
            80
        );
    }

    public function register_settings() {
        register_setting(
            $this->plugin_name . '_options_group',
            'custom_project_settings',
            array($this, 'sanitize_settings')
        );

        add_settings_section(
            $this->plugin_name . '_general_section',
            esc_html__('General Configuration', 'custom-project'),
            array($this, 'render_section_info'),
            $this->plugin_name
        );

        add_settings_field(
            'display_title',
            esc_html__('Display Title', 'custom-project'),
            array($this, 'render_title_field'),
            $this->plugin_name,
            $this->plugin_name . '_general_section'
        );

        add_settings_field(
            'custom_message',
            esc_html__('Feedback Message', 'custom-project'),
            array($this, 'render_message_field'),
            $this->plugin_name,
            $this->plugin_name . '_general_section'
        );
    }

    public function sanitize_settings($input) {
        $sanitized = array();
        if (isset($input['display_title'])) {
            $sanitized['display_title'] = sanitize_text_field($input['display_title']);
        }
        if (isset($input['custom_message'])) {
            $sanitized['custom_message'] = sanitize_textarea_field($input['custom_message']);
        }
        return $sanitized;
    }

    public function render_section_info() {
        echo '<p>' . esc_html__('Configure the operational settings for Untitled Project.', 'custom-project') . '</p>';
    }

    public function render_title_field() {
        $options = get_option('custom_project_settings');
        $title = isset($options['display_title']) ? $options['display_title'] : '';
        echo '<input type="text" name="custom_project_settings[display_title]" value="' . esc_attr($title) . '" class="regular-text" />';
    }

    public function render_message_field() {
        $options = get_option('custom_project_settings');
        $msg = isset($options['custom_message']) ? $options['custom_message'] : '';
        echo '<textarea name="custom_project_settings[custom_message]" rows="4" class="large-text">' . esc_textarea($msg) . '</textarea>';
    }

    public function display_plugin_setup_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'custom-project'));
        }
        include_once CUSTOM_PROJECT_PATH . 'admin/partials/custom-project-admin-display.php';
    }
}
