<?php
/**
 * Provide a admin area view for the plugin
 *
 * @package custom-project
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap custom-project-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <div class="custom-project-admin-container">
        <form method="post" action="options.php">
            <?php
            settings_fields($this->plugin_name . '_options_group');
            do_settings_sections($this->plugin_name);
            submit_button(esc_html__('Save Settings', 'custom-project'));
            ?>
        </form>

        <div class="custom-project-info-box">
            <h3><?php esc_html_e('Shortcode Usage', 'custom-project'); ?></h3>
            <p><?php esc_html_e('Place the following shortcode on any post or page to display the interactive component:', 'custom-project'); ?></p>
            <code>[custom-project]</code>
        </div>
    </div>
</div>
