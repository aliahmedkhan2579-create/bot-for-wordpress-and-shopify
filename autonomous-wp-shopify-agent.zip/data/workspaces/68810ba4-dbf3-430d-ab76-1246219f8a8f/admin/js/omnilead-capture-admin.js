(function($) {
    'use strict';
    $(document).ready(function() {
        console.log('OmniLead Capture Form admin panel initialized.');
    });
})(jQuery);
