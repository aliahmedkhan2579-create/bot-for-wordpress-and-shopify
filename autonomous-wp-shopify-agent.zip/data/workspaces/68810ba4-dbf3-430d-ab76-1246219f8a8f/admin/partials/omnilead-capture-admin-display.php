<?php
/**
 * Provide a admin area view for the plugin
 *
 * @package omnilead-capture
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap omnilead-capture-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <div class="omnilead-capture-admin-container">
        <form method="post" action="options.php">
            <?php
            settings_fields($this->plugin_name . '_options_group');
            do_settings_sections($this->plugin_name);
            submit_button(esc_html__('Save Settings', 'omnilead-capture'));
            ?>
        </form>

        <div class="omnilead-capture-info-box">
            <h3><?php esc_html_e('Shortcode Usage', 'omnilead-capture'); ?></h3>
            <p><?php esc_html_e('Place the following shortcode on any post or page to display the interactive component:', 'omnilead-capture'); ?></p>
            <code>[omnilead-capture]</code>
        </div>
    </div>
</div>
