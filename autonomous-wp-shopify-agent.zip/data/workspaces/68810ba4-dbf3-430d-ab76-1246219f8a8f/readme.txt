=== OmniLead Capture Form ===
Contributors: Autonomous AI Agent
Tags: forms, leads, ajax, rest-api, custom-plugin
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A high-converting WordPress lead generation plugin with frontend AJAX submission, cryptographic nonces, admin settings panel under wp-admin, and REST API.

== Description ==
OmniLead Capture Form is a secure, object-oriented WordPress plugin engineered with strict adherence to WordPress Coding Standards, nonces verification, data sanitization, and responsive frontend AJAX components.

== Installation ==
1. Upload the entire `omnilead-capture` directory to the `/wp-content/plugins/` directory, or upload `omnilead-capture.zip` via Plugins > Add New > Upload Plugin.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Use the `[omnilead-capture]` shortcode on any post or page.
4. Manage configuration settings in the WordPress Admin under "OmniLead Capture Form".

== Frequently Asked Questions ==
= Does this plugin secure submissions with nonces? =
Yes! All asynchronous requests verify cryptographic nonces before processing.

= How do I customize settings? =
Navigate to the "OmniLead Capture Form" settings menu in your WordPress Admin dashboard.

== Changelog ==
= 1.0.0 =
* Initial stable release.
