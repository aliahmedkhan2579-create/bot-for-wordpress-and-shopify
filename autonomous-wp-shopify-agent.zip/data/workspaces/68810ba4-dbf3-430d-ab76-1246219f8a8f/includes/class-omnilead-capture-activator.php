<?php
/**
 * Fired during plugin activation
 *
 * @package omnilead-capture
 */

if (!defined('ABSPATH')) {
    exit;
}

class OmnileadCapture_Activator {
    public static function activate() {
        // Set up default plugin options
        if (false === get_option('omnilead_capture_settings')) {
            $default_settings = array(
                'enable_feature' => 1,
                'notify_email'   => get_option('admin_email'),
                'display_title'  => 'OmniLead Capture Form',
                'custom_message' => 'Thank you for interacting with our plugin!',
            );
            add_option('omnilead_capture_settings', $default_settings);
        }

        // Flush rewrite rules for any registered custom post types / routes
        flush_rewrite_rules();
    }
}
