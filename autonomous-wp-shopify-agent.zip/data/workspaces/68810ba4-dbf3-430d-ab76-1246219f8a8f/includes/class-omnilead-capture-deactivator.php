<?php
/**
 * Fired during plugin deactivation
 *
 * @package omnilead-capture
 */

if (!defined('ABSPATH')) {
    exit;
}

class OmnileadCapture_Deactivator {
    public static function deactivate() {
        // Flush rewrite rules on deactivation
        flush_rewrite_rules();
    }
}
