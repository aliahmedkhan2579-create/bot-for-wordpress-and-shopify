<?php
/**
 * The core plugin class
 *
 * @package omnilead-capture
 */

if (!defined('ABSPATH')) {
    exit;
}

class OmnileadCapture {
    protected $loader;
    protected $plugin_name;
    protected $version;

    public function __construct() {
        $this->version = OMNILEAD_CAPTURE_VERSION;
        $this->plugin_name = 'omnilead-capture';

        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
        require_once OMNILEAD_CAPTURE_PATH . 'includes/class-omnilead-capture-loader.php';
        require_once OMNILEAD_CAPTURE_PATH . 'admin/class-omnilead-capture-admin.php';
        require_once OMNILEAD_CAPTURE_PATH . 'public/class-omnilead-capture-public.php';

        $this->loader = new OmnileadCapture_Loader();
    }

    private function define_admin_hooks() {
        $plugin_admin = new OmnileadCapture_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        $this->loader->add_action('admin_menu', $plugin_admin, 'add_plugin_admin_menu');
        $this->loader->add_action('admin_init', $plugin_admin, 'register_settings');
    }

    private function define_public_hooks() {
        $plugin_public = new OmnileadCapture_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');

        // Shortcode registration
        $this->loader->add_action('init', $plugin_public, 'register_shortcodes');

        // AJAX handlers
        $this->loader->add_action('wp_ajax_omnilead_capture_submit', $plugin_public, 'handle_ajax_submission');
        $this->loader->add_action('wp_ajax_nopriv_omnilead_capture_submit', $plugin_public, 'handle_ajax_submission');

        // REST API
        $this->loader->add_action('rest_api_init', $plugin_public, 'register_rest_routes');
    }

    public function run() {
        $this->loader->run();
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }
}
