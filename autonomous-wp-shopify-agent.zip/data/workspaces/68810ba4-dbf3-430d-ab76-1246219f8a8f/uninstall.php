<?php
/**
 * Fired when the plugin is deleted.
 *
 * @package omnilead-capture
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options created by the plugin
delete_option('omnilead_capture_settings');
