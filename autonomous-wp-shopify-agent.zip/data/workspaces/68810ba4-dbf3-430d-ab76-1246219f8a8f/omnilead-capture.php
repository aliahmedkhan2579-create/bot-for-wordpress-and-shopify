<?php
/**
 * The plugin bootstrap file
 *
 * @package           omnilead-capture
 *
 * @wordpress-plugin
 * Plugin Name:       OmniLead Capture Form
 * Plugin URI:        https://example.com/omnilead-capture
 * Description:       A high-converting WordPress lead generation plugin with frontend AJAX submission, cryptographic nonces, admin settings panel under wp-admin, and REST API.
 * Version:           1.0.0
 * Author:            Autonomous AI Agent
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       omnilead-capture
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('OMNILEAD_CAPTURE_VERSION', '1.0.0');
define('OMNILEAD_CAPTURE_PATH', plugin_dir_path(__FILE__));
define('OMNILEAD_CAPTURE_URL', plugin_dir_url(__FILE__));
define('OMNILEAD_CAPTURE_BASENAME', plugin_basename(__FILE__));

/**
 * The code that runs during plugin activation.
 */
function activate_omnilead_capture() {
    require_once OMNILEAD_CAPTURE_PATH . 'includes/class-omnilead-capture-activator.php';
    OmnileadCapture_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_omnilead_capture() {
    require_once OMNILEAD_CAPTURE_PATH . 'includes/class-omnilead-capture-deactivator.php';
    OmnileadCapture_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_omnilead_capture');
register_deactivation_hook(__FILE__, 'deactivate_omnilead_capture');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require_once OMNILEAD_CAPTURE_PATH . 'includes/class-omnilead-capture.php';

/**
 * Begins execution of the plugin.
 */
function run_omnilead_capture() {
    $plugin = new OmnileadCapture();
    $plugin->run();
}
run_omnilead_capture();
