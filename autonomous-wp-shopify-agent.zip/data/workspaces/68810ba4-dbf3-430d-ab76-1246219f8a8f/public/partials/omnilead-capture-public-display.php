<?php
/**
 * Provide a public-facing view for the plugin
 *
 * @package omnilead-capture
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="omnilead-capture-card" id="omnilead-capture-container">
    <div class="omnilead-capture-card-header">
        <h3 class="omnilead-capture-title"><?php echo esc_html($title); ?></h3>
        <p class="omnilead-capture-desc"><?php esc_html_e('Submit your information securely below.', 'omnilead-capture'); ?></p>
    </div>

    <form class="omnilead-capture-form" id="omnilead-capture-form" method="post">
        <div class="omnilead-capture-field-group">
            <label for="omnilead-capture-user-name"><?php esc_html_e('Your Name', 'omnilead-capture'); ?> <span class="required">*</span></label>
            <input type="text" id="omnilead-capture-user-name" name="user_name" required placeholder="<?php esc_attr_e('Jane Doe', 'omnilead-capture'); ?>" class="omnilead-capture-input" />
        </div>

        <div class="omnilead-capture-field-group">
            <label for="omnilead-capture-user-email"><?php esc_html_e('Email Address', 'omnilead-capture'); ?> <span class="required">*</span></label>
            <input type="email" id="omnilead-capture-user-email" name="user_email" required placeholder="<?php esc_attr_e('jane@example.com', 'omnilead-capture'); ?>" class="omnilead-capture-input" />
        </div>

        <div class="omnilead-capture-field-group">
            <label for="omnilead-capture-message"><?php esc_html_e('Message / Inquiries', 'omnilead-capture'); ?></label>
            <textarea id="omnilead-capture-message" name="message" rows="3" placeholder="<?php esc_attr_e('Enter your message here...', 'omnilead-capture'); ?>" class="omnilead-capture-textarea"></textarea>
        </div>

        <div class="omnilead-capture-actions">
            <button type="submit" class="omnilead-capture-submit-btn">
                <span class="btn-text"><?php esc_html_e('Submit Now', 'omnilead-capture'); ?></span>
                <span class="btn-spinner" style="display:none;">&#9696;</span>
            </button>
        </div>

        <div class="omnilead-capture-response" style="display:none;" role="alert"></div>
    </form>
</div>
