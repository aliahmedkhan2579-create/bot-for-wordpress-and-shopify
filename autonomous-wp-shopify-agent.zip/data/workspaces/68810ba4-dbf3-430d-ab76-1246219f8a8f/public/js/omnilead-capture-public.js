(function($) {
    'use strict';

    $(document).ready(function() {
        var $form = $('#omnilead-capture-form');
        var $response = $form.find('.omnilead-capture-response');
        var $btn = $form.find('.omnilead-capture-submit-btn');
        var $btnText = $btn.find('.btn-text');
        var $btnSpinner = $btn.find('.btn-spinner');

        $form.on('submit', function(e) {
            e.preventDefault();

            var data = {
                action: 'omnilead_capture_submit',
                nonce: omnilead_capture_ajax_obj.nonce,
                user_name: $('#omnilead-capture-user-name').val(),
                user_email: $('#omnilead-capture-user-email').val(),
                message: $('#omnilead-capture-message').val()
            };

            $btn.prop('disabled', true);
            $btnSpinner.show();
            $response.hide().removeClass('success error');

            $.post(omnilead_capture_ajax_obj.ajax_url, data)
                .done(function(res) {
                    $response.addClass('success').html(res.data.message).fadeIn();
                    $form[0].reset();
                })
                .fail(function(xhr) {
                    var errMsg = 'An unexpected error occurred. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errMsg = xhr.responseJSON.data.message;
                    }
                    $response.addClass('error').html(errMsg).fadeIn();
                })
                .always(function() {
                    $btn.prop('disabled', false);
                    $btnSpinner.hide();
                });
        });
    });
})(jQuery);
