(function($) {
    'use strict';

    $(document).ready(function() {
        var $form = $('#vanguard-agency-form');
        var $response = $form.find('.vanguard-agency-response');
        var $btn = $form.find('.vanguard-agency-submit-btn');
        var $btnText = $btn.find('.btn-text');
        var $btnSpinner = $btn.find('.btn-spinner');

        $form.on('submit', function(e) {
            e.preventDefault();

            var data = {
                action: 'vanguard_agency_submit',
                nonce: vanguard_agency_ajax_obj.nonce,
                user_name: $('#vanguard-agency-user-name').val(),
                user_email: $('#vanguard-agency-user-email').val(),
                message: $('#vanguard-agency-message').val()
            };

            $btn.prop('disabled', true);
            $btnSpinner.show();
            $response.hide().removeClass('success error');

            $.post(vanguard_agency_ajax_obj.ajax_url, data)
                .done(function(res) {
                    $response.addClass('success').html(res.data.message).fadeIn();
                    $form[0].reset();
                })
                .fail(function(xhr) {
                    var errMsg = 'An unexpected error occurred. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errMsg = xhr.responseJSON.data.message;
                    }
                    $response.addClass('error').html(errMsg).fadeIn();
                })
                .always(function() {
                    $btn.prop('disabled', false);
                    $btnSpinner.hide();
                });
        });
    });
})(jQuery);
