<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}

class VanguardAgency_Public {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, VANGUARD_AGENCY_URL . 'public/css/vanguard-agency-public.css', array(), $this->version, 'all');
    }

    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, VANGUARD_AGENCY_URL . 'public/js/vanguard-agency-public.js', array('jquery'), $this->version, true);

        wp_localize_script($this->plugin_name, 'vanguard_agency_ajax_obj', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('vanguard_agency_nonce_action'),
        ));
    }

    public function register_shortcodes() {
        add_shortcode('vanguard-agency', array($this, 'render_shortcode'));
    }

    public function render_shortcode($atts, $content = null) {
        $options = get_option('vanguard_agency_settings', array());
        $title = !empty($options['display_title']) ? $options['display_title'] : 'chack';

        ob_start();
        include VANGUARD_AGENCY_PATH . 'public/partials/vanguard-agency-public-display.php';
        return ob_get_clean();
    }

    public function handle_ajax_submission() {
        // Nonce check for security
        check_ajax_referer('vanguard_agency_nonce_action', 'nonce');

        $user_name  = isset($_POST['user_name']) ? sanitize_text_field(wp_unslash($_POST['user_name'])) : '';
        $user_email = isset($_POST['user_email']) ? sanitize_email(wp_unslash($_POST['user_email'])) : '';
        $message    = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';

        if (empty($user_name) || empty($user_email)) {
            wp_send_json_error(array(
                'message' => esc_html__('Please fill in all required fields.', 'vanguard-agency'),
            ), 400);
        }

        if (!is_email($user_email)) {
            wp_send_json_error(array(
                'message' => esc_html__('Please provide a valid email address.', 'vanguard-agency'),
            ), 400);
        }

        $options = get_option('vanguard_agency_settings', array());
        $custom_msg = !empty($options['custom_message']) ? $options['custom_message'] : esc_html__('Thank you for reaching out!', 'vanguard-agency');

        wp_send_json_success(array(
            'message' => esc_html($custom_msg),
            'data'    => array(
                'name'  => esc_html($user_name),
                'email' => esc_html($user_email),
            ),
        ));
    }

    public function register_rest_routes() {
        register_rest_route('vanguard-agency/v1', '/status', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_api_status'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_api_status($request) {
        return new WP_REST_Response(array(
            'status'  => 'active',
            'plugin'  => 'chack',
            'version' => $this->version,
            'time'    => current_time('mysql'),
        ), 200);
    }
}
