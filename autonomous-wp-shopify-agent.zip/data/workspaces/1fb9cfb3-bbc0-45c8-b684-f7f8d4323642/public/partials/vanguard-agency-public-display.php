<?php
/**
 * Provide a public-facing view for the plugin
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="vanguard-agency-card" id="vanguard-agency-container">
    <div class="vanguard-agency-card-header">
        <h3 class="vanguard-agency-title"><?php echo esc_html($title); ?></h3>
        <p class="vanguard-agency-desc"><?php esc_html_e('Submit your information securely below.', 'vanguard-agency'); ?></p>
    </div>

    <form class="vanguard-agency-form" id="vanguard-agency-form" method="post">
        <div class="vanguard-agency-field-group">
            <label for="vanguard-agency-user-name"><?php esc_html_e('Your Name', 'vanguard-agency'); ?> <span class="required">*</span></label>
            <input type="text" id="vanguard-agency-user-name" name="user_name" required placeholder="<?php esc_attr_e('Jane Doe', 'vanguard-agency'); ?>" class="vanguard-agency-input" />
        </div>

        <div class="vanguard-agency-field-group">
            <label for="vanguard-agency-user-email"><?php esc_html_e('Email Address', 'vanguard-agency'); ?> <span class="required">*</span></label>
            <input type="email" id="vanguard-agency-user-email" name="user_email" required placeholder="<?php esc_attr_e('jane@example.com', 'vanguard-agency'); ?>" class="vanguard-agency-input" />
        </div>

        <div class="vanguard-agency-field-group">
            <label for="vanguard-agency-message"><?php esc_html_e('Message / Inquiries', 'vanguard-agency'); ?></label>
            <textarea id="vanguard-agency-message" name="message" rows="3" placeholder="<?php esc_attr_e('Enter your message here...', 'vanguard-agency'); ?>" class="vanguard-agency-textarea"></textarea>
        </div>

        <div class="vanguard-agency-actions">
            <button type="submit" class="vanguard-agency-submit-btn">
                <span class="btn-text"><?php esc_html_e('Submit Now', 'vanguard-agency'); ?></span>
                <span class="btn-spinner" style="display:none;">&#9696;</span>
            </button>
        </div>

        <div class="vanguard-agency-response" style="display:none;" role="alert"></div>
    </form>
</div>
