(function($) {
    'use strict';
    $(document).ready(function() {
        console.log('chack admin panel initialized.');
    });
})(jQuery);
