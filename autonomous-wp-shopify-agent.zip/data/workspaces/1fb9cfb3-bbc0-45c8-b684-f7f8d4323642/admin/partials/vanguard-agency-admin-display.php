<?php
/**
 * Provide a admin area view for the plugin
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vanguard-agency-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <div class="vanguard-agency-admin-container">
        <form method="post" action="options.php">
            <?php
            settings_fields($this->plugin_name . '_options_group');
            do_settings_sections($this->plugin_name);
            submit_button(esc_html__('Save Settings', 'vanguard-agency'));
            ?>
        </form>

        <div class="vanguard-agency-info-box">
            <h3><?php esc_html_e('Shortcode Usage', 'vanguard-agency'); ?></h3>
            <p><?php esc_html_e('Place the following shortcode on any post or page to display the interactive component:', 'vanguard-agency'); ?></p>
            <code>[vanguard-agency]</code>
        </div>
    </div>
</div>
