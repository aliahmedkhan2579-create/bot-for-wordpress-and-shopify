<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}

class VanguardAgency_Admin {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name . '-admin', VANGUARD_AGENCY_URL . 'admin/css/vanguard-agency-admin.css', array(), $this->version, 'all');
    }

    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name . '-admin', VANGUARD_AGENCY_URL . 'admin/js/vanguard-agency-admin.js', array('jquery'), $this->version, false);
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            esc_html__('chack Settings', 'vanguard-agency'),
            esc_html__('chack', 'vanguard-agency'),
            'manage_options',
            $this->plugin_name,
            array($this, 'display_plugin_setup_page'),
            'dashicons-admin-generic',
            80
        );
    }

    public function register_settings() {
        register_setting(
            $this->plugin_name . '_options_group',
            'vanguard_agency_settings',
            array($this, 'sanitize_settings')
        );

        add_settings_section(
            $this->plugin_name . '_general_section',
            esc_html__('General Configuration', 'vanguard-agency'),
            array($this, 'render_section_info'),
            $this->plugin_name
        );

        add_settings_field(
            'display_title',
            esc_html__('Display Title', 'vanguard-agency'),
            array($this, 'render_title_field'),
            $this->plugin_name,
            $this->plugin_name . '_general_section'
        );

        add_settings_field(
            'custom_message',
            esc_html__('Feedback Message', 'vanguard-agency'),
            array($this, 'render_message_field'),
            $this->plugin_name,
            $this->plugin_name . '_general_section'
        );
    }

    public function sanitize_settings($input) {
        $sanitized = array();
        if (isset($input['display_title'])) {
            $sanitized['display_title'] = sanitize_text_field($input['display_title']);
        }
        if (isset($input['custom_message'])) {
            $sanitized['custom_message'] = sanitize_textarea_field($input['custom_message']);
        }
        return $sanitized;
    }

    public function render_section_info() {
        echo '<p>' . esc_html__('Configure the operational settings for chack.', 'vanguard-agency') . '</p>';
    }

    public function render_title_field() {
        $options = get_option('vanguard_agency_settings');
        $title = isset($options['display_title']) ? $options['display_title'] : '';
        echo '<input type="text" name="vanguard_agency_settings[display_title]" value="' . esc_attr($title) . '" class="regular-text" />';
    }

    public function render_message_field() {
        $options = get_option('vanguard_agency_settings');
        $msg = isset($options['custom_message']) ? $options['custom_message'] : '';
        echo '<textarea name="vanguard_agency_settings[custom_message]" rows="4" class="large-text">' . esc_textarea($msg) . '</textarea>';
    }

    public function display_plugin_setup_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'vanguard-agency'));
        }
        include_once VANGUARD_AGENCY_PATH . 'admin/partials/vanguard-agency-admin-display.php';
    }
}
