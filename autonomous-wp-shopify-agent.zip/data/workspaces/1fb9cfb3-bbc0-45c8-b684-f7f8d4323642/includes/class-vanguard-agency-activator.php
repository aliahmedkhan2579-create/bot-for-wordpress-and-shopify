<?php
/**
 * Fired during plugin activation
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}

class VanguardAgency_Activator {
    public static function activate() {
        // Set up default plugin options
        if (false === get_option('vanguard_agency_settings')) {
            $default_settings = array(
                'enable_feature' => 1,
                'notify_email'   => get_option('admin_email'),
                'display_title'  => 'chack',
                'custom_message' => 'Thank you for interacting with our plugin!',
            );
            add_option('vanguard_agency_settings', $default_settings);
        }

        // Flush rewrite rules for any registered custom post types / routes
        flush_rewrite_rules();
    }
}
