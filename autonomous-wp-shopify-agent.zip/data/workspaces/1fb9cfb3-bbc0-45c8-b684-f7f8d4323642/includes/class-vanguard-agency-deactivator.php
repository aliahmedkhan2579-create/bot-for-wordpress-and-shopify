<?php
/**
 * Fired during plugin deactivation
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}

class VanguardAgency_Deactivator {
    public static function deactivate() {
        // Flush rewrite rules on deactivation
        flush_rewrite_rules();
    }
}
