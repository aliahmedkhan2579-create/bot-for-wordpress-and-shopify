<?php
/**
 * The core plugin class
 *
 * @package vanguard-agency
 */

if (!defined('ABSPATH')) {
    exit;
}

class VanguardAgency {
    protected $loader;
    protected $plugin_name;
    protected $version;

    public function __construct() {
        $this->version = VANGUARD_AGENCY_VERSION;
        $this->plugin_name = 'vanguard-agency';

        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
        require_once VANGUARD_AGENCY_PATH . 'includes/class-vanguard-agency-loader.php';
        require_once VANGUARD_AGENCY_PATH . 'admin/class-vanguard-agency-admin.php';
        require_once VANGUARD_AGENCY_PATH . 'public/class-vanguard-agency-public.php';

        $this->loader = new VanguardAgency_Loader();
    }

    private function define_admin_hooks() {
        $plugin_admin = new VanguardAgency_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        $this->loader->add_action('admin_menu', $plugin_admin, 'add_plugin_admin_menu');
        $this->loader->add_action('admin_init', $plugin_admin, 'register_settings');
    }

    private function define_public_hooks() {
        $plugin_public = new VanguardAgency_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');

        // Shortcode registration
        $this->loader->add_action('init', $plugin_public, 'register_shortcodes');

        // AJAX handlers
        $this->loader->add_action('wp_ajax_vanguard_agency_submit', $plugin_public, 'handle_ajax_submission');
        $this->loader->add_action('wp_ajax_nopriv_vanguard_agency_submit', $plugin_public, 'handle_ajax_submission');

        // REST API
        $this->loader->add_action('rest_api_init', $plugin_public, 'register_rest_routes');
    }

    public function run() {
        $this->loader->run();
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }
}
