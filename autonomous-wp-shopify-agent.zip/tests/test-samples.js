/**
 * End-to-End Test Suite for Autonomous WordPress & Shopify ZIP Generator AI Agent
 * Tests generation, multi-stage validation, auto-fixing, packaging, and archive verification for:
 * 1. WordPress Theme
 * 2. WordPress Plugin
 * 3. Shopify Online Store 2.0 Theme
 */

const fs = require('node:fs');
const path = require('node:path');
const AdmZip = require('adm-zip');

const config = require('../src/config');
const { ProjectManager } = require('../src/workspace/project-manager');
const { AgentOrchestrator } = require('../src/orchestrator');

async function runTestSuite() {
  console.log('===============================================================');
  console.log(' STARTING AUTONOMOUS ZIP GENERATOR VERIFICATION TEST SUITE');
  console.log('===============================================================\n');

  const pm = new ProjectManager(config);
  const orchestrator = new AgentOrchestrator(pm, config);

  const testCases = [
    {
      id: 'test-case-1',
      type: 'wordpress_theme',
      name: 'Vanguard Modern Agency',
      slug: 'vanguard-agency',
      prompt: 'A modern, responsive creative agency WordPress theme with WooCommerce shop integration, custom header, hero section, portfolio loop, and widget sidebar.'
    },
    {
      id: 'test-case-2',
      type: 'wordpress_plugin',
      name: 'OmniLead Capture Form',
      slug: 'omnilead-capture',
      prompt: 'A high-converting WordPress lead generation plugin with frontend AJAX submission, cryptographic nonces, admin settings panel under wp-admin, and REST API.'
    },
    {
      id: 'test-case-3',
      type: 'shopify_theme',
      name: 'Aura Artisan Coffee & Goods',
      slug: 'aura-artisan-theme',
      prompt: 'A Shopify Online Store 2.0 theme for an artisan coffee roastery. Features announcement bar, JSON templates, product variant picker, customizable schema, and slide-out cart drawer.'
    }
  ];

  const results = [];

  for (const tc of testCases) {
    console.log(`\n---------------------------------------------------------------`);
    console.log(`RUNNING TEST CASE: ${tc.name} [${tc.type.toUpperCase()}]`);
    console.log(`---------------------------------------------------------------`);

    try {
      // 1. Create project
      const project = pm.createProject({
        type: tc.type,
        name: tc.name,
        slug: tc.slug,
        prompt: tc.prompt
      });
      console.log(`✓ Project initialized: ID=${project.id}, Slug=${tc.slug}`);

      // 2. Run 10-step autonomous workflow
      console.log(`⚡ Executing 10-step autonomous development pipeline...`);
      const result = await orchestrator.runWorkflow(project.id, { provider: 'builtin' });

      // 3. Verify ZIP Existence & Integrity
      const zipPath = result.zipInfo.zipPath;
      if (!fs.existsSync(zipPath)) {
        throw new Error(`Generated ZIP archive not found on disk at ${zipPath}`);
      }

      const stats = fs.statSync(zipPath);
      console.log(`✓ ZIP created successfully: ${path.basename(zipPath)} (${(stats.size / 1024).toFixed(1)} KB)`);

      // 4. Open and inspect ZIP entries
      const zip = new AdmZip(zipPath);
      const entries = zip.getEntries();
      console.log(`✓ ZIP opened and verified: Contains ${entries.length} files`);

      // Check required files based on type
      if (tc.type === 'wordpress_theme') {
        const hasStyleCss = entries.some(e => e.entryName.endsWith('style.css'));
        const hasFunctionsPhp = entries.some(e => e.entryName.endsWith('functions.php'));
        const hasScreenshot = entries.some(e => e.entryName.endsWith('screenshot.png'));
        if (!hasStyleCss || !hasFunctionsPhp || !hasScreenshot) {
          throw new Error('WordPress Theme ZIP missing essential files (style.css, functions.php, or screenshot.png)!');
        }
        console.log(`✓ WordPress Theme structure confirmed (style.css, functions.php, screenshot.png present)`);
      } else if (tc.type === 'wordpress_plugin') {
        const hasMainPhp = entries.some(e => e.entryName.endsWith(`${tc.slug}.php`));
        const hasUninstall = entries.some(e => e.entryName.endsWith('uninstall.php'));
        if (!hasMainPhp || !hasUninstall) {
          throw new Error('WordPress Plugin ZIP missing main PHP or uninstall.php!');
        }
        console.log(`✓ WordPress Plugin structure confirmed (${tc.slug}.php, uninstall.php present)`);
      } else if (tc.type === 'shopify_theme') {
        const hasThemeLiquid = entries.some(e => e.entryName.includes('layout/theme.liquid'));
        const hasIndexJson = entries.some(e => e.entryName.includes('templates/index.json'));
        const hasSettingsSchema = entries.some(e => e.entryName.includes('config/settings_schema.json'));
        if (!hasThemeLiquid || !hasIndexJson || !hasSettingsSchema) {
          throw new Error('Shopify Theme ZIP missing layout/theme.liquid, templates/index.json, or settings_schema.json!');
        }
        console.log(`✓ Shopify Online Store 2.0 structure confirmed (layout/theme.liquid, templates/index.json, config/settings_schema.json present)`);
      }

      console.log(`✓ Validation Tests: ${result.validationReport.length} tests evaluated.`);
      result.validationReport.forEach(t => {
        console.log(`    - [${t.status.toUpperCase()}] ${t.name}: ${t.details}`);
      });

      results.push({
        testCase: tc.name,
        type: tc.type,
        status: 'PASSED',
        zipPath,
        fileCount: entries.length,
        fileSize: (stats.size / 1024).toFixed(1) + ' KB',
        sha256: result.zipInfo.sha256
      });

    } catch (err) {
      console.error(`✗ TEST FAILED for ${tc.name}:`, err.message);
      results.push({
        testCase: tc.name,
        type: tc.type,
        status: 'FAILED',
        error: err.message
      });
    }
  }

  console.log(`\n===============================================================`);
  console.log(` SUMMARY OF VERIFICATION RESULTS`);
  console.log(`===============================================================`);
  console.table(results);

  const allPassed = results.every(r => r.status === 'PASSED');
  if (allPassed) {
    console.log(`\n🎉 ALL 3 SAMPLE WORKFLOW TESTS PASSED COMPLETELY!`);
    process.exit(0);
  } else {
    console.error(`\n❌ SOME TESTS FAILED`);
    process.exit(1);
  }
}

runTestSuite();
